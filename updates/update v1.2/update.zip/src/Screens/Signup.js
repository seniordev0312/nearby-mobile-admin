import {
  Dimensions,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useRef, useState} from 'react';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Input from '../Modules/Input';
import PressableText from '../Modules/PressableText';
import RoundButton from '../Modules/RoundButton';
import auth from '@react-native-firebase/auth';
import {isEmailValid} from '../Utils/Utils';

const {width, height} = Dimensions.get('window');

const SignupScreen = (props) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isPasswordHidden, setIsPasswordHidden] = useState(true);
  const [inputFocus, setInputFocus] = useState({
    email: false,
    password: false,
    name: false,
  });
  const inputEmail = useRef(null);
  const inputPass = useRef(null);

  const focusFunction = (input) => {
    if (input === 'email') {
      setInputFocus({password: false, name: false, email: true});
      inputEmail.current.focus();
    } else {
      setInputFocus({email: false, name: false, password: true});
      inputPass.current.focus();
    }
  };

  const signupHandler = async () => {
    setError(null);
    if (!email || !password) {
      setError('All fields are required');
    } else if (!isEmailValid(email)) {
      setError('Email is not valid');
    } else if (password.length <= 5) {
      setError('Password must be at least 5 characters');
    } else {
      setIsLoading(true);
      try {
        await auth().createUserWithEmailAndPassword(email, password);
      } catch (err) {
        switch (err.code) {
          case 'auth/email-already-in-use':
            setError('This email is already associated with an account.');
            break;
          case 'auth/invalid-email':
            setError(
              'The email is invalid, please provide a valid email address i.e mail@mail.com',
            );
            break;
          case 'auth/weak-password':
            setError(
              'Password is to easy to guess, please use a strong password',
            );
            break;
          default:
            setError(
              'There is something wrong, please contact with administrator',
            );
            break;
        }
        setIsLoading(false);
      }
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Pressable
        style={styles.mainContainer}
        onPress={() => {
          setInputFocus(
            Object.assign(
              ...Object.keys(inputFocus).map((k) => ({[k]: false})),
            ),
          );
          inputEmail.current.blur();
          inputPass.current.blur();
        }}>
        <Text style={styles.bold}>Let's get started</Text>
        <Text style={styles.desc}>
          Create your account, it's free and only takes a minute
        </Text>
        <View style={styles.line} />
        <Input
          onPress={() => focusFunction('email')}
          iconName={'mail-outline'}
          focusEvent={inputFocus.email}
          ref={inputEmail}
          align="center"
          placeholder={'Email'}
          autoCompleteType="email"
          placeholderTextColor={
            inputFocus.email ? Colors.primary : Colors.placeholderColor
          }
          onFocus={() => focusFunction('email')}
          keyboardType={'email-address'}
          returnKeyType={'next'}
          textContentType="emailAddress"
          maxLength={254}
          onSubmitEditing={() => inputPass.current.focus()}
          onChangeText={(val) => setEmail(val)}
        />
        <Input
          onPress={() => focusFunction()}
          iconName={'lock-open-outline'}
          focusEvent={inputFocus.password}
          ref={inputPass}
          align="center"
          maxLength={128}
          placeholder={'Password'}
          placeholderTextColor={
            inputFocus.password ? Colors.primary : Colors.placeholderColor
          }
          onFocus={() => setInputFocus({email: false, password: true})}
          secureTextEntry={isPasswordHidden}
          isEye={true}
          eyePress={() => setIsPasswordHidden(!isPasswordHidden)}
          passIcon={isPasswordHidden ? 'eye-outline' : 'eye-off-outline'}
          onChangeText={(val) => setPassword(val)}
        />
        {!!error && <CenterText text={error} />}
        <RoundButton
          title="Next step"
          isLoading={isLoading}
          onPress={!isLoading ? () => signupHandler() : null}
        />
        <View style={styles.signinContainer}>
          <Text style={styles.signinText}>Already have account? </Text>
          <PressableText
            textStyle={styles.signin}
            text="Sign In"
            onPress={() => !isLoading && props.navigation.goBack()}
          />
        </View>
      </Pressable>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F4F4F4',
    top: 14,
  },
  mainContainer: {
    top: 10,
    height,
    width,
    flex: 1,
    alignSelf: 'center',
  },
  bold: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    color: Colors.textColor,
  },
  desc: {
    color: '#7A7A7A',
    textAlign: 'center',
    fontSize: 18,
  },
  errorContainer: {
    alignSelf: 'center',
    margin: 8,
  },
  errorText: {
    color: '#ff0033',
    fontSize: 18,
    textAlign: 'center',
  },
  signinContainer: {
    flexDirection: 'row',
    marginTop: '15%',
    alignSelf: 'center',
  },
  signinText: {
    fontSize: 18,
  },
  signin: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default SignupScreen;
