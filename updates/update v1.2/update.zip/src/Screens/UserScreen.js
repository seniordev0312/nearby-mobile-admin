import {
  ActivityIndicator,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import {
  AdEventType,
  InterstitialAd,
  TestIds,
} from '@react-native-firebase/admob';
import MapView, {Marker} from 'react-native-maps';
import React, {useEffect, useState} from 'react';
import {ageCal, db, usersCol} from '../Utils/Utils';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Config from '../Utils/Config';
import Modal from 'react-native-modal';
import OneSignal from 'react-native-onesignal';
import RoundButton from '../Modules/RoundButton';
import VerifiedBadge from '../Modules/VerifiedBadge';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

const adUnitId = __DEV__
  ? TestIds.INTERSTITIAL
  : Platform.select({
      ios: Config.FULLSCREEN_AD.IOS,
      android: Config.FULLSCREEN_AD.ANDROID,
    });

const interstitial = InterstitialAd.createForAdRequest(adUnitId, {
  requestNonPersonalizedAdsOnly: true,
  keywords: ['fashion', 'clothing'],
});

const UserProfile = (props) => {
  const {uid} = props.route.params;
  const [isLoading, setIsLoading] = useState(true);
  const [coinLoading, setCoinLoading] = useState(false);
  const [user, setUser] = useState(null);
  const [coinsModal, setCoinsModal] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [loggedUser, setLoggedUser] = useState(null);
  const [credits, setCredits] = useState('');
  const [loadAd, setLoadedAd] = useState(false);

  useEffect(() => {
    let isMounted = true;

    const getLoggedUser = () => {
      if (isMounted) {
        usersCol.doc(auth().currentUser.uid).onSnapshot((authedUser) => {
          setLoggedUser(authedUser.data());
        });
      }
    };

    getLoggedUser();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    let isMounted = true;

    const getUser = () => {
      if (isMounted) {
        usersCol.doc(uid).onSnapshot((snap) => {
          if (snap.exists) {
            setUser(snap.data());
          }
          setIsLoading(false);
        });
      }
    };

    getUser();

    return () => {
      isMounted = false;
    };
  }, [uid]);

  const coinSendHandler = async () => {
    setError(null);
    setSuccessMessage(null);
    if (credits.length !== 0) {
      // eslint-disable-next-line radix
      let credit = parseInt(credits);
      if (isNaN(credit)) {
        setError('Please input valid value');
      } else {
        if (credit > loggedUser?.credit) {
          setError('You dont have enough coins to send.');
        } else {
          setCoinLoading(true);
          try {
            await db
              .collection('users')
              .doc(uid)
              .update({credit: firestore.FieldValue.increment(credit)});
            await db
              .collection('users')
              .doc(auth().currentUser.uid)
              .update({credit: firestore.FieldValue.increment(-credit)});
            const update = [
              {
                fromId: auth().currentUser.uid,
                message: `${loggedUser?.name} send you ${credit} 🎁🎉`,
                createdAt: new Date(),
                profilePic: auth().currentUser.photoURL,
              },
            ];
            await db
              .collection('notifications')
              .doc(uid)
              .set(
                {notifications: firestore.FieldValue.arrayUnion(...update)},
                {merge: true},
              );
            const notificationObj = {
              contents: {en: `${loggedUser?.name} send you ${credit} 🎁🎉`},
              headings: {en: 'Credit Received 💰'},
              app_url: 'nearby://notification',
              large_icon: auth().currentUser.photoURL,
              include_player_ids: [user?.onesignalId],
            };
            const json = JSON.stringify(notificationObj);
            OneSignal.postNotification(json);
            setSuccessMessage('Credit transferred successfully');
            setCoinLoading(false);
          } catch (err) {
            setError('Error occured, please contact to app admin');
            setCoinLoading(false);
          }
        }
      }
    } else {
      setError('Please input credit to send.');
    }
  };

  useEffect(() => {
    const eventListener = interstitial.onAdEvent((type) => {
      if (type === AdEventType.LOADED) {
        setLoadedAd(true);
      }
      if (type === AdEventType.CLOSED) {
        setLoadedAd(false);
      }
    });

    // Start loading the interstitial straight away
    interstitial.load();

    // Unsubscribe from events on unmount
    return () => {
      eventListener();
    };
  }, []);

  if (loadAd) {
    interstitial.show();
  }

  if (isLoading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.container}>
        <View style={styles.profileDetails}>
          <View style={styles.profileShadow}>
            <Image
              source={{uri: user?.profileAvtar}}
              style={styles.profilePic}
            />
            {!!user?.isVerified && (
              <VerifiedBadge size={20} style={styles.verifyBadge} />
            )}
          </View>
          <Text style={styles.username}>{user?.name}</Text>
          <View style={styles.userDetails}>
            <Text style={styles.gender}>{user?.gender}</Text>
            <Text style={styles.gender}>{`${ageCal(
              user?.dateOfBirth,
            )} years`}</Text>
          </View>
          {!!user?.bio && <Text style={styles.bio}>{user?.bio}</Text>}
          <View style={styles.userDetails}>
            <RoundButton
              title="Send credits"
              containerStyle={styles.button}
              onPress={() => setCoinsModal(true)}
            />
            <RoundButton
              title="Message"
              containerStyle={styles.button}
              onPress={() =>
                props.navigation.push('ChatScreen', {
                  userid: uid,
                  username: user?.name,
                  onesignalId: user?.onesignalId,
                  dp: user?.profileAvtar,
                })
              }
            />
          </View>
          <View style={styles.map}>
            <MapView
              region={{
                latitude: user?.coords.latitude,
                longitude: user?.coords.longitude,
                latitudeDelta: 0.0922,
                longitudeDelta: 0.0421,
              }}
              style={[{...StyleSheet.absoluteFillObject}, styles.mapView]}>
              <Marker coordinate={user?.coords} />
            </MapView>
          </View>
          <View style={styles.margin} />
          <Modal
            isVisible={coinsModal}
            style={styles.modal}
            swipeDirection="down"
            onBackButtonPress={() => !coinLoading && setCoinsModal(false)}
            onBackdropPress={() => !coinLoading && setCoinsModal(false)}
            onSwipeComplete={(e) => !coinLoading && setCoinsModal(false)}>
            <View style={styles.modalContainer}>
              <View style={styles.modalLine} />
              <Text style={styles.modalHeading}>Send Coins</Text>
              <Text style={styles.desc}>
                {`You have ${loggedUser?.credit} credit available`}
              </Text>
              <TextInput
                placeholder="Enter credit"
                style={styles.textInput}
                maxLength={7}
                value={credits}
                onChangeText={(val) => setCredits(val)}
                keyboardType="number-pad"
              />
              {!!successMessage && (
                <CenterText textStyle={styles.success} text={successMessage} />
              )}
              {!!error && <CenterText textStyle={styles.error} text={error} />}
              <RoundButton
                title="Send"
                containerStyle={styles.sendButton}
                isLoading={coinLoading}
                onPress={() => !coinLoading && coinSendHandler()}
              />
            </View>
          </Modal>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    flexDirection: 'column',
  },
  verifyBadge: {
    position: 'absolute',
    top: '80%',
    right: '10%',
  },
  profileShadow: {
    width: 200,
    height: 200,
    borderRadius: 100,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
    elevation: 2,
  },
  profilePic: {
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  profileDetails: {
    top: heightPercentageToDP('6%'),
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    flex: 1,
  },
  map: {
    width: '90%',
    height: heightPercentageToDP('20%'),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
    marginVertical: 10,
  },
  username: {
    fontSize: 22,
    marginVertical: 8,
    fontFamily: 'GothamMedium',
  },
  bio: {
    fontFamily: 'GothamLight',
    fontSize: 20,
    marginVertical: 8,
  },
  userDetails: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  gender: {
    textTransform: 'capitalize',
    fontFamily: 'GothamLight',
    fontSize: 22,
    marginHorizontal: 10,
  },
  button: {
    borderRadius: 8,
    width: widthPercentageToDP('38%'),
    marginHorizontal: 10,
  },
  modal: {
    margin: 0,
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: '#fff',
    height: heightPercentageToDP('34%'),
    width: '100%',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    paddingHorizontal: 20,
  },
  modalHeading: {
    fontSize: 22,
    fontFamily: 'GothamMedium',
    textAlign: 'center',
    marginVertical: 6,
  },
  desc: {
    fontSize: 20,
    color: '#8e8e8e',
    fontFamily: 'GothamLight',
    textAlign: 'center',
    marginVertical: 8,
  },
  modalLine: {
    width: '10%',
    borderBottomWidth: 3,
    borderBottomColor: '#8e8e8e',
    alignSelf: 'center',
    marginTop: 10,
  },
  textInput: {
    borderWidth: 1,
    borderRadius: 8,
    fontFamily: 'GothamLight',
    fontSize: 20,
  },
  sendButton: {
    marginVertical: 8,
  },
  error: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
    textAlign: 'center',
  },
  success: {
    color: '#4F8A10',
    fontFamily: 'GothamMedium',
    fontSize: 18,
    textAlign: 'center',
  },
  margin: {
    height: 60,
    marginBottom: 50,
  },
  mapView: {
    borderRadius: 10.4,
  },
});

export default UserProfile;
