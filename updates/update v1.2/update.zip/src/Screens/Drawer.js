import {DrawerContentScrollView, DrawerItem} from '@react-navigation/drawer';
import {Image, StyleSheet, Text, View} from 'react-native';

import Colors from '../Utils/Colors';
import Icon from 'react-native-vector-icons/Ionicons';
import React from 'react';
import auth from '@react-native-firebase/auth';
import {displayName} from '../../app.json';
import {heightPercentageToDP} from '../Utils/DpToPixel';

export default function Drawer(props) {
  const user = auth().currentUser;

  return (
    <View style={styles.container}>
      <View style={styles.shadow}>
        <Image source={{uri: user?.photoURL}} style={styles.profileImage} />
      </View>
      <Text style={styles.username}>{user?.displayName}</Text>
      <DrawerContentScrollView {...props}>
        <DrawerItem
          label="Edit Profile"
          icon={({color, size}) => (
            <Icon name="create-outline" color={Colors.primary} size={28} />
          )}
          onPress={() =>
            props.navigation.navigate('Profile', {screen: 'Settings'})
          }
          labelStyle={styles.labelStyle}
        />
        <DrawerItem
          label="Support"
          icon={({color, size}) => (
            <Icon name="headset-outline" color={Colors.primary} size={28} />
          )}
          onPress={() =>
            props.navigation.navigate('Profile', {screen: 'Support'})
          }
          labelStyle={styles.labelStyle}
        />
        <DrawerItem
          label="Withdraw Points"
          icon={({color, size}) => (
            <Icon name="cash-outline" color={Colors.primary} size={28} />
          )}
          onPress={() =>
            props.navigation.navigate('Profile', {screen: 'Withdraw'})
          }
          labelStyle={styles.labelStyle}
        />
        <DrawerItem
          label="About Us"
          icon={({color, size}) => (
            <Icon
              name="information-circle-outline"
              color={Colors.primary}
              size={28}
            />
          )}
          onPress={() =>
            props.navigation.navigate('Profile', {screen: 'AboutUs'})
          }
          labelStyle={styles.labelStyle}
        />
        <DrawerItem
          label="Our Terms"
          icon={({color, size}) => (
            <Icon name="reader-outline" color={Colors.primary} size={28} />
          )}
          onPress={() =>
            props.navigation.navigate('Profile', {screen: 'Terms'})
          }
          labelStyle={styles.labelStyle}
        />
        <DrawerItem
          label="Privacy Policy"
          icon={({color, size}) => (
            <Icon
              name="shield-checkmark-outline"
              color={Colors.primary}
              size={28}
            />
          )}
          onPress={() =>
            props.navigation.navigate('Profile', {screen: 'PrivacyPolicy'})
          }
          labelStyle={styles.labelStyle}
        />
        <DrawerItem
          label="Logout"
          icon={({color, size}) => (
            <Icon name="log-out-outline" color={Colors.primary} size={28} />
          )}
          onPress={() => auth().signOut()}
          labelStyle={styles.labelStyle}
        />
      </DrawerContentScrollView>
      <Text
        style={
          styles.copyRight
        }>{`© ${displayName} ${new Date().getFullYear()}`}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  labelStyle: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
    color: Colors.primary,
  },
  copyRight: {
    marginVertical: 10,
    fontSize: 17,
    fontFamily: 'GothamMedium',
    color: '#8e8e8e',
    position: 'absolute',
    textAlign: 'center',
    bottom: heightPercentageToDP('8%'),
    left: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  shadow: {
    width: 100,
    height: 100,
    borderRadius: 50,
    elevation: 3,
    alignSelf: 'center',
    marginVertical: 10,
  },
  username: {
    fontFamily: 'GothamMedium',
    fontSize: 19,
    textAlign: 'center',
  },
});
