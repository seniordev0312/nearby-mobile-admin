import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {db, dbTimeStamp, usersCol} from '../Utils/Utils';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Config from '../Utils/Config';
import Icon from 'react-native-vector-icons/Ionicons';
import Loader from '../Modules/Loader';
import Modal from 'react-native-modal';
import OneSignal from 'react-native-onesignal';
import PressableText from '../Modules/PressableText';
import RoundButton from '../Modules/RoundButton';
import auth from '@react-native-firebase/auth';

const WithdrawScreen = (props) => {
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [coins, setCoins] = useState(null);
  const [name, setName] = useState('');
  const [iban, setIban] = useState('');
  const [country, setCountry] = useState('');
  const [swiftCode, setSwiftCode] = useState('');
  const [address, setAddress] = useState('');
  const [paypalEmail, setPaypalEmail] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [requestLoader, setRequestLoader] = useState(false);
  const [user, setUser] = useState(null);
  const [method, setMethod] = useState('Paypal');
  const [methodModal, setMethodModal] = useState(false);
  const [isAlready, setIsAlready] = useState(null);

  useEffect(() => {
    let isMounted = true;

    const getUser = () => {
      if (isMounted) {
        usersCol.doc(auth().currentUser.uid).onSnapshot(async (snap) => {
          setUser(snap.data());
        });
      }
    };

    getUser();

    return () => {
      isMounted = false;
    };
  }, [user]);

  useEffect(() => {
    let isMounted = true;

    const getRequest = () => {
      if (isMounted) {
        db.collection('withdrawRequests')
          .doc(auth().currentUser.uid)
          .onSnapshot(async (snap) => {
            if (snap.exists) {
              setIsAlready(snap.data());
            }
            setIsLoading(false);
          });
      }
    };

    getRequest();

    return () => {
      isMounted = false;
    };
  }, [user]);

  const queryHandler = async () => {
    setError(null);
    setSuccessMessage(null);
    // eslint-disable-next-line radix
    let inputCoins = parseInt(coins);
    if (user?.credit <= Config.MIN_WITHDRAW || user?.credit === 0) {
      setError("You don't have enough credit to make withdrawal request");
    } else if (isNaN(inputCoins)) {
      setError('Please enter valid value');
    } else if (inputCoins <= Config.MIN_WITHDRAW) {
      setError(`Amount must not be less than ${Config.MIN_WITHDRAW}`);
    } else {
      const onesignalId = await OneSignal.getDeviceState();
      console.log('Id => ', onesignalId.userId);
      if (method === 'Paypal') {
        setRequestLoader(true);
        try {
          await db
            .collection('withdrawRequests')
            .doc(auth().currentUser.uid)
            .set(
              {
                username: auth().currentUser.displayName,
                profileAvtar: auth().currentUser.photoURL,
                paypalAddress: paypalEmail,
                coins: inputCoins,
                createdAt: dbTimeStamp,
                method: 'Paypal',
                notifId: onesignalId.userId,
                status: 'Pending',
              },
              {
                merge: true,
              },
            );
        } catch (err) {
          setError('Error, please try later');
        }
        setRequestLoader(false);
      } else {
        setRequestLoader(true);
        try {
          await db
            .collection('withdrawRequests')
            .doc(auth().currentUser.uid)
            .set({
              username: auth().currentUser.displayName,
              profileAvtar: auth().currentUser.photoURL,
              method: 'Bank',
              iban: iban,
              fullName: name,
              country: country,
              swiftCode: swiftCode,
              address: address,
              coins: inputCoins,
              createdAt: dbTimeStamp,
              notifId: onesignalId.userId,
              status: 'Pending',
            });
        } catch (err) {
          setError('Error, please try later');
        }
        setRequestLoader(false);
      }
    }
  };

  const methodHandler = (val) => {
    setMethod(val);
    setMethodModal(false);
  };

  if (isLoading) {
    return <Loader />;
  }

  return (
    <View style={styles.container}>
      <View style={styles.detailContainer}>
        <View style={styles.buttonContainer}>
          <Text style={styles.credit}>Available Balance:</Text>
          <Text style={styles.credit}>{user?.credit}</Text>
          <Text style={styles.text}>
            Per coin equals to {Config.PER_COIN_EQUAL_TO} {Config.CURRENCY_CODE}
          </Text>
          <Text style={styles.minText}>
            Minimum Withdraw: {Config.MIN_WITHDRAW}
          </Text>
        </View>
      </View>
      <View style={styles.formContainer}>
        {isAlready ? (
          <View>
            <Text style={styles.heading}>Request Pending</Text>
            <View style={styles.row}>
              <Text style={styles.rowHead}>Coins</Text>
              <Text style={styles.rowHead}>Method</Text>
              <Text style={styles.rowHead}>Status</Text>
            </View>
            <View style={styles.row}>
              <Text style={styles.rowData}>{isAlready?.coins}</Text>
              <Text style={styles.rowData}>{isAlready?.method}</Text>
              <Text style={styles.rowData}>{isAlready?.status}</Text>
            </View>
            <Text style={styles.methodText}>
              Please wait for your pending request to complete, before making
              next request.
            </Text>
          </View>
        ) : (
          <ScrollView>
            <Text style={styles.heading}>Withdraw Method</Text>
            <Pressable
              style={styles.methodInput}
              onPress={() => setMethodModal(true)}>
              <Text style={styles.methodText}>{method}</Text>
              <Icon
                name="chevron-down-outline"
                size={28}
                color={Colors.primary}
                style={styles.carrot}
              />
            </Pressable>
            <TextInput
              placeholder="Coins"
              style={styles.input}
              keyboardType="numeric"
              onChangeText={(val) => setCoins(val)}
            />
            {method === 'Paypal' ? (
              <TextInput
                placeholder="PayPal email"
                style={styles.input}
                autoCompleteType="email"
                keyboardType="email-address"
                maxLength={135}
                onChangeText={(val) => setPaypalEmail(val)}
              />
            ) : (
              <>
                <TextInput
                  placeholder="IBAN"
                  style={styles.input}
                  maxLength={34}
                  onChangeText={(val) => setIban(val)}
                />
                <TextInput
                  placeholder="Country"
                  style={styles.input}
                  maxLength={90}
                  onChangeText={(val) => setCountry(val)}
                />
                <TextInput
                  placeholder="Full Name"
                  style={styles.input}
                  autoCompleteType="name"
                  maxLength={68}
                  onChangeText={(val) => setName(val)}
                />
                <TextInput
                  placeholder="Swift code"
                  style={styles.input}
                  maxLength={11}
                  onChangeText={(val) => setSwiftCode(val)}
                />
                <TextInput
                  placeholder="Address"
                  style={styles.addressInput}
                  autoCompleteType="street-address"
                  maxLength={135}
                  onChangeText={(val) => setAddress(val)}
                />
              </>
            )}
            {!!successMessage && (
              <CenterText textStyle={styles.success} text={successMessage} />
            )}
            {!!error && <CenterText textStyle={styles.error} text={error} />}
            <RoundButton
              title="Request withdrawal"
              containerStyle={styles.submitButton}
              isLoading={requestLoader}
              onPress={() => !requestLoader && queryHandler()}
            />
            <Modal
              isVisible={methodModal}
              style={styles.view}
              onBackButtonPress={() => setMethodModal(false)}
              onBackdropPress={() => setMethodModal(false)}>
              <View style={styles.modalContainer}>
                <View style={styles.modalLine} />
                <PressableText
                  style={styles.modalButton}
                  textStyle={styles.modalButtonText}
                  text="Bank"
                  onPress={() => methodHandler('Bank')}
                />
                <PressableText
                  icon={true}
                  style={styles.modalButton}
                  textStyle={styles.modalButtonText}
                  text="Paypal"
                  onPress={() => methodHandler('Paypal')}
                />
              </View>
              {!!error && <CenterText text={error} />}
            </Modal>
          </ScrollView>
        )}
        <View style={styles.margin} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  detailContainer: {
    marginTop: 40,
    height: '20%',
    marginBottom: 10,
  },
  formContainer: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    flex: 1,
    elevation: 3,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  buttonContainer: {
    alignSelf: 'center',
    width: '90%',
    height: '100%',
    backgroundColor: Colors.primary,
    borderRadius: 12,
  },
  inputLabel: {
    marginLeft: 10,
    fontFamily: 'GothamLight',
    fontSize: 22,
  },
  methodText: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
    marginHorizontal: 13,
  },
  input: {
    width: '95%',
    alignSelf: 'center',
    borderRadius: 8,
    fontFamily: 'GothamLight',
    fontSize: 20,
    elevation: 3,
    backgroundColor: '#fff',
    marginBottom: 6,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  addressInput: {
    textAlignVertical: 'top',
    width: widthPercentageToDP('94%'),
    alignSelf: 'center',
    borderRadius: 12,
    height: heightPercentageToDP('30%'),
    fontFamily: 'GothamLight',
    fontSize: 20,
    backgroundColor: '#fff',
    elevation: 3,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  submitButton: {
    marginVertical: 6,
    borderRadius: 8,
    width: '50%',
  },
  error: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
  },
  success: {
    color: '#4F8A10',
    fontFamily: 'GothamMedium',
    fontSize: 18,
    textAlign: 'center',
  },
  credit: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
    color: '#fff',
    textAlign: 'center',
    marginTop: 8,
  },
  text: {
    fontFamily: 'GothamLight',
    fontSize: 22,
    color: '#fff',
    textAlign: 'center',
    marginTop: 10,
  },
  minText: {
    fontFamily: 'GothamLight',
    fontSize: 22,
    color: '#fff',
    textAlign: 'center',
    bottom: 0,
    position: 'absolute',
    alignSelf: 'center',
    marginBottom: 8,
  },
  methodInput: {
    width: '95%',
    height: 45,
    borderRadius: 8,
    elevation: 2,
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignSelf: 'center',
    marginVertical: 10,
    alignItems: 'center',
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  carrot: {
    right: 5,
    position: 'absolute',
  },
  modalContainer: {
    backgroundColor: 'white',
    height: '22%',
    width: '100%',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  modalButton: {
    alignItems: 'center',
    width: '95%',
    elevation: 3,
    borderRadius: 6,
    backgroundColor: '#fff',
    height: '35%',
    alignSelf: 'center',
    marginBottom: 5,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  modalButtonText: {
    fontSize: 22,
    marginLeft: 12,
    fontFamily: 'GothamMedium',
  },
  view: {
    margin: 0,
    justifyContent: 'flex-end',
  },
  modalLine: {
    width: '10%',
    borderBottomWidth: 3,
    borderBottomColor: '#8e8e8e',
    alignSelf: 'center',
    marginTop: 10,
  },
  heading: {
    fontFamily: 'GothamMedium',
    alignSelf: 'center',
    fontSize: 18,
    marginVertical: 6,
  },
  margin: {
    height: 60,
    marginBottom: 5,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 10,
    marginVertical: 10,
  },
  rowHead: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
    textAlign: 'center',
  },
  rowData: {
    fontFamily: 'GothamLight',
    fontSize: 20,
    textAlign: 'center',
  },
});

export default WithdrawScreen;
