import {Image, StyleSheet, Text, View} from 'react-native';

import Colors from '../Utils/Colors';
import React from 'react';

const SplashScreen = () => {
  return (
    <View style={styles.container}>
      <Image
        source={require('../../assets/images/Logo.png')}
        style={styles.logo}
      />
      <Text style={styles.slogan}>Chat, Meet, Friend</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 200,
    height: 50,
  },
  slogan: {
    color: '#fff',
    fontSize: 20,
    alignSelf: 'flex-end',
    marginHorizontal: 25,
  },
});

export default SplashScreen;
