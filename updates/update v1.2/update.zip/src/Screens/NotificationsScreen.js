import {
  ActivityIndicator,
  Image,
  Platform,
  StyleSheet,
  Text,
  View,
  VirtualizedList,
} from 'react-native';
import {
  AdEventType,
  InterstitialAd,
  TestIds,
} from '@react-native-firebase/admob';
import React, {useEffect, useState} from 'react';
import {db, uuid} from '../Utils/Utils';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import Colors from '../Utils/Colors';
import SiteConfig from '../Utils/Config';
import auth from '@react-native-firebase/auth';

const adUnitId = __DEV__
  ? TestIds.INTERSTITIAL
  : Platform.select({
      ios: SiteConfig.FULLSCREEN_AD.IOS,
      android: SiteConfig.FULLSCREEN_AD.ANDROID,
    });
const interstitial = InterstitialAd.createForAdRequest(adUnitId, {
  requestNonPersonalizedAdsOnly: true,
  keywords: ['fashion', 'clothing'],
});

const NotificationsScreen = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const [notifications, setNotifications] = useState([]);
  const [loadAd, setLoadedAd] = useState(false);

  useEffect(() => {
    const eventListener = interstitial.onAdEvent((type) => {
      if (type === AdEventType.LOADED) {
        setLoadedAd(true);
      }
      if (type === AdEventType.CLOSED) {
        setLoadedAd(false);
      }
    });

    // Start loading the interstitial straight away
    interstitial.load();

    // Unsubscribe from events on unmount
    return () => {
      eventListener();
    };
  }, []);

  useEffect(() => {
    let isMounted = true;

    const getUser = () => {
      if (isMounted) {
        db.collection('notifications')
          .doc(auth().currentUser.uid)
          .onSnapshot(async (snap) => {
            setNotifications(snap.data().notifications.reverse());
          });
        setIsLoading(false);
      }
    };

    getUser();

    return () => {
      isMounted = false;
    };
  }, [isLoading]);

  if (loadAd) {
    interstitial.show();
  }

  if (isLoading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <VirtualizedList
        data={notifications}
        initialNumToRender={6}
        keyExtractor={uuid}
        getItem={(item, index) => item[index]}
        getItemCount={() => notifications.length}
        renderItem={({item}) => {
          return (
            <View style={styles.notification}>
              <Image
                source={{uri: item?.profilePic}}
                style={styles.profilePic}
                resizeMode="cover"
              />
              <Text style={styles.message}>{item?.message}</Text>
            </View>
          );
        }}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
      <View style={styles.margin} />
    </View>
  );
};

const styles = StyleSheet.create({
  loader: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  notificationsContainer: {
    flex: 1,
    top: 7,
  },
  notification: {
    width: widthPercentageToDP('96%'),
    height: heightPercentageToDP('7%'),
    alignSelf: 'center',
    borderRadius: 8,
    alignItems: 'center',
    flexDirection: 'row',
    padding: 10,
    marginVertical: 4,
  },
  message: {
    fontFamily: 'GothamMedium',
    fontSize: 16,
    flexWrap: 'wrap',
    flexShrink: 1,
    color: Colors.primary,
  },
  profilePic: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  margin: {
    height: 50,
  },
  separator: {
    borderWidth: 0.5,
    borderColor: '#f4f4f4',
  },
});

export default NotificationsScreen;
