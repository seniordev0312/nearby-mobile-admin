import {
  Image,
  Linking,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {db, dbTimeStamp} from '../Utils/Utils';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Icon from 'react-native-vector-icons/Ionicons';
import OneSignal from 'react-native-onesignal';
import RoundButton from '../Modules/RoundButton';
import auth from '@react-native-firebase/auth';

const Button = (props) => {
  return (
    <TouchableOpacity onPress={props.action} style={styles.button}>
      <View style={{...styles.buttonStyle, backgroundColor: props.maincolor}}>
        <Icon name={props.iconName} size={24} color={props.iconColor} />
      </View>
      <Text style={{...styles.text, color: props.textColor}}>{props.text}</Text>
    </TouchableOpacity>
  );
};

const SupportScreen = (props) => {
  const [query, setQuery] = useState('');
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const queryHandler = async () => {
    if (query.length !== 0) {
      const user = auth().currentUser;
      setError(null);
      setIsLoading(true);
      try {
        const onesignalId = await OneSignal.getDeviceState();
        await db.collection('support').add({
          userid: user?.uid,
          username: user?.displayName,
          userPic: user?.photoURL,
          createdAt: dbTimeStamp,
          message: query,
          notifId: onesignalId.userId,
        });
        setSuccessMessage(
          "Your query has been received to us, we'll contact you ASAP",
        );
        setIsLoading(false);
      } catch (err) {
        setError(err.message);
        setIsLoading(false);
      }
    } else {
      setError('Please enter message');
    }
  };
  return (
    <View style={styles.container}>
      <View style={styles.detailContainer}>
        <Image
          source={require('../../assets/images/support.png')}
          style={styles.image}
        />
        <View style={styles.buttonContainer}>
          <Button
            iconName={'call'}
            text="Call Us"
            textColor="#DAB11B"
            maincolor={'rgba(232,197,71,0.3)'}
            iconColor={'#E4BB25'}
            action={() => Linking.openURL('tel: +923212325161')}
          />
          <Button
            iconName={'mail'}
            text="Email Us"
            textColor="#330561"
            maincolor={'rgba(82,7,156,0.3)'}
            iconColor={'#3D0675'}
            action={() => Linking.openURL('mailto:anwerthesolangi@gmail.com')}
          />
        </View>
      </View>
      <View style={styles.formContainer}>
        <ScrollView>
          <Text style={styles.heading}>Quick Support</Text>
          <Text style={styles.inputLabel}>
            Message: <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            multiline
            placeholder="Your Query?"
            style={styles.input}
            autoCorrect={false}
            onChangeText={(val) => setQuery(val)}
          />
          {!!successMessage && (
            <CenterText textStyle={styles.success} text={successMessage} />
          )}
          {!!error && <CenterText textStyle={styles.error} text={error} />}
          <RoundButton
            title="Submit"
            containerStyle={styles.submitButton}
            isLoading={isLoading}
            onPress={() => !isLoading && queryHandler()}
          />
        </ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  detailContainer: {
    justifyContent: 'space-between',
    marginBottom: heightPercentageToDP('2%'),
  },
  formContainer: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    flex: 1,
    elevation: 3,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  image: {
    width: widthPercentageToDP('85%'),
    height: heightPercentageToDP('25%'),
    top: heightPercentageToDP('5%'),
    alignSelf: 'center',
    marginBottom: heightPercentageToDP('6%'),
  },
  buttonContainer: {
    width: widthPercentageToDP('70%'),
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-evenly',
  },
  button: {
    backgroundColor: '#fff',
    width: widthPercentageToDP(27),
    height: heightPercentageToDP(12),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 8,
    elevation: 3,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
  },
  buttonStyle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
  heading: {
    fontFamily: 'GothamMedium',
    fontSize: 20,
    marginVertical: 10,
    textAlign: 'center',
  },
  inputLabel: {
    marginLeft: 10,
    fontFamily: 'GothamLight',
    fontSize: 22,
  },
  required: {
    fontFamily: 'GothamMedium',
    fontSize: 20,
    color: 'red',
  },
  input: {
    textAlignVertical: 'top',
    borderWidth: 1,
    width: widthPercentageToDP('94%'),
    alignSelf: 'center',
    borderRadius: 12,
    height: heightPercentageToDP('30%'),
    borderColor: '#8e8e8e',
    fontFamily: 'GothamLight',
    fontSize: 20,
  },
  submitButton: {
    marginVertical: 6,
  },
  error: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
  },
  success: {
    color: '#4F8A10',
    fontFamily: 'GothamMedium',
    fontSize: 18,
    textAlign: 'center',
  },
});

export default SupportScreen;
