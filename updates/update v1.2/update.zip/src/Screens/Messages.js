import {
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  VirtualizedList,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import Colors from '../Utils/Colors';
import Icon from 'react-native-vector-icons/Ionicons';
import Loader from '../Modules/Loader';
import auth from '@react-native-firebase/auth';
import {db} from '../Utils/Utils';

const MessagesScreen = (props) => {
  const [isLoading, setisLoading] = useState(true);
  const [lastMessages, setLastMessages] = useState([]);

  useEffect(() => {
    let isMounted = true;

    const getUser = () => {
      if (isMounted) {
        db.collection('recentMessages')
          .doc(auth().currentUser.uid)
          .onSnapshot(async (snap) => {
            if (snap.exists) {
              setLastMessages(Object.values(snap.data()));
            }
          });
        setisLoading(false);
      }
    };

    getUser();

    return () => {
      isMounted = false;
    };
  }, []);

  if (isLoading) {
    return <Loader />;
  }

  return (
    <VirtualizedList
      data={lastMessages}
      initialNumToRender={7}
      getItemCount={() => lastMessages.length}
      keyExtractor={(item) => item._id}
      getItem={(data, index) => data[index]}
      contentContainerStyle={styles.container}
      renderItem={({item}) => {
        return (
          <TouchableOpacity
            style={styles.profileContainer}
            onPress={() =>
              props.navigation.push('ChatScreen', {
                userid: item._id,
                username: item?.username,
                onesignalId: item?.onesignalId,
                dp: item?.profilePic,
              })
            }>
            <Image
              source={{uri: item.profilePic}}
              style={styles.profilePic}
              resizeMode="cover"
            />
            <View style={styles.username}>
              <Text style={styles.text}>{item.username}</Text>
              {item.text && !item.image ? (
                <Text
                  // eslint-disable-next-line react-native/no-inline-styles
                  style={{
                    ...styles.messageStyle,
                    color: !item.read ? '#303030' : 'rgba(0,0,0,.54)',
                  }}>
                  {item.text}
                </Text>
              ) : item.text && item.image ? (
                <View style={styles.rowStyle}>
                  <Icon name="image-outline" color="#000" size={18} />
                  <Text
                    // eslint-disable-next-line react-native/no-inline-styles
                    style={{
                      ...styles.messageStyle,
                      color: !item.read ? '#303030' : 'rgba(0,0,0,.54)',
                    }}>
                    {item.text}
                  </Text>
                </View>
              ) : (
                <View style={styles.rowStyle}>
                  <Icon
                    name="image-outline"
                    color={!item.read ? '#303030' : 'rgba(0,0,0,.54)'}
                    size={20}
                  />
                  <Text
                    // eslint-disable-next-line react-native/no-inline-styles
                    style={{
                      ...styles.messageStyle,
                      color: !item.read ? '#303030' : 'rgba(0,0,0,.54)',
                    }}>
                    Photo
                  </Text>
                </View>
              )}
            </View>
          </TouchableOpacity>
        );
      }}
      ListEmptyComponent={() => {
        return (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyHeading} numberOfLines={2}>
              It's pretty quiet in here, don't you think?
            </Text>
            <Text style={styles.emptyMsgDisc}>
              Message, or share your favorite image directly with users near
              you, or discover users.
            </Text>
          </View>
        );
      }}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f8f9fc',
    flex: 1,
  },
  text: {
    color: Colors.primary,
    fontSize: 17,
    fontFamily: 'GothamMedium',
  },
  profileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 10,
    width: widthPercentageToDP('96%'),
    height: heightPercentageToDP('11%'),
    alignSelf: 'center',
    borderRadius: 8,
    padding: 10,
    marginVertical: 4,
    backgroundColor: '#fff',
  },
  profilePic: {
    width: 70,
    height: 70,
    borderRadius: 40,
  },
  username: {
    flexDirection: 'column',
    justifyContent: 'space-around',
    marginHorizontal: 10,
    maxHeight: '60%',
  },
  messageStyle: {
    fontFamily: 'GothamLight',
    textAlign: 'left',
    fontSize: 20,
    color: Colors.primary,
  },
  rowStyle: {
    flexDirection: 'row',
  },
  emptyContainer: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyHeading: {
    fontSize: 18,
    marginVertical: 8,
    fontFamily: 'GothamMedium',
    color: Colors.primary,
    width: '90%',
    textAlign: 'center',
  },
  desc: {
    fontFamily: 'GothamLight',
    fontSize: 20,
    marginVertical: 8,
    color: Colors.primary,
  },
  emptyMsgDisc: {
    textAlign: 'center',
    fontFamily: 'GothamLight',
    fontSize: 20,
    marginVertical: 8,
    color: Colors.primary,
    width: '90%',
    flexWrap: 'wrap',
    flexShrink: 1,
  },
});

export default MessagesScreen;
