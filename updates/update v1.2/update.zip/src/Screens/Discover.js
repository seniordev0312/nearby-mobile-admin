import {
  ActivityIndicator,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  VirtualizedList,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {db, distance, shuffle, usersCol} from '../Utils/Utils';

import Colors from '../Utils/Colors';
import auth from '@react-native-firebase/auth';
import {widthPercentageToDP} from '../Utils/DpToPixel';

class UserModal {
  constructor(id, name, profileAvtar, coords) {
    this.id = id;
    this.name = name;
    this.profileAvtar = profileAvtar;
    this.coords = coords;
  }
}

const Discover = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const [featuredUsers, setFeaturedUsers] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [initialCoords, setInitialCoords] = useState('');

  useEffect(() => {
    let isMounted = true;

    const getCoords = async () => {
      const user = await usersCol.doc(auth().currentUser.uid).get();
      if (isMounted) {
        if (user.exists) {
          setInitialCoords({
            lat: user.data().coords?.latitude,
            long: user.data().coords?.longitude,
          });
        }
      }
    };

    getCoords();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    let isMounted = true;

    const fetchFeaturedUsers = async () => {
      let updatedArray = [];
      db.collection('featuredUsers')
        .get()
        .then(async (snap) => {
          const shuffled = shuffle(
            snap.docs.map(
              (user) =>
                new UserModal(
                  user.id,
                  user.data().name,
                  user.data().profileAvtar,
                ),
            ),
          );
          const slicedArray = shuffled
            .slice(0, 10)
            .filter((u) => u.id !== auth().currentUser.uid);
          slicedArray.map((user) => {
            updatedArray.push(user);
          });
        });
      if (isMounted) {
        setFeaturedUsers(updatedArray);
      }
    };

    fetchFeaturedUsers();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    let isMounted = true;

    const getUsers = async () => {
      const dbUsers = await usersCol.get();
      if (isMounted) {
        const updatedUsers = dbUsers.docs
          .filter((u) => u.id !== auth().currentUser.uid)
          .map((user) => {
            const isExist = allUsers.find((u) => u.id === user.id);
            if (isExist) {
              return isExist;
            } else {
              return new UserModal(
                user.id,
                user.data().name,
                user.data().profileAvtar,
                user.data().coords,
              );
            }
          });
        setAllUsers(updatedUsers);
        setIsLoading(false);
      }
    };

    getUsers();

    return () => {
      isMounted = false;
    };
  }, [allUsers]);

  const distanceBetweenUser = (selectedProfile) => {
    const d = distance(
      initialCoords?.lat,
      initialCoords?.long,
      selectedProfile?.coords?.latitude,
      selectedProfile?.coords?.longitude,
    );
    if (d <= 1000) {
      return `${Math.ceil(d)} meters`;
    } else {
      const km = Math.ceil(d / 1000);
      return `${km} KM`;
    }
  };

  if (isLoading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator color={Colors.primary} size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.heading}>Featured Users</Text>

        <VirtualizedList
          data={featuredUsers}
          initialNumToRender={7}
          getItemCount={() => featuredUsers.length}
          keyExtractor={(item) => item?.id}
          getItem={(data, index) => data[index]}
          horizontal
          renderItem={({item}) => {
            return (
              <TouchableOpacity
                style={styles.profile}
                key={item?.id}
                onPress={() =>
                  props.navigation.navigate('Profile', {
                    screen: 'UserScreen',
                    params: {
                      uid: item?.id,
                      name: item?.name,
                    },
                  })
                }>
                <Image
                  source={{uri: item?.profileAvtar}}
                  style={styles.profileAvtar}
                />
                <Text style={styles.username}>{item?.name}</Text>
              </TouchableOpacity>
            );
          }}
          ListEmptyComponent={() => {
            return (
              <View style={styles.emptyContainer}>
                <Text style={styles.desc}>Be the first to be featured ⚡️</Text>
              </View>
            );
          }}
        />
      </View>
      <View style={styles.allUser}>
        <Text style={styles.heading}>Users</Text>
      </View>
      <VirtualizedList
        data={allUsers}
        initialNumToRender={7}
        getItemCount={() => allUsers.length}
        keyExtractor={(item) => item?.id}
        getItem={(data, index) => data[index]}
        renderItem={({item}) => {
          return (
            <TouchableOpacity
              style={styles.userContainer}
              key={item?.id}
              onPress={() =>
                props.navigation.navigate('Profile', {
                  screen: 'UserScreen',
                  params: {
                    uid: item?.id,
                    name: item?.name,
                  },
                })
              }>
              <Image
                source={{uri: item?.profileAvtar}}
                style={styles.profileAvtar}
              />
              <View style={styles.descContainer}>
                <Text style={styles.usertext}>{item?.name}</Text>
                <Text style={styles.desc}>{`${distanceBetweenUser(
                  item,
                )} away `}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
      <View style={styles.margin} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  loader: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileAvtar: {
    width: 65,
    height: 65,
    borderRadius: 12,
  },
  featuredUsers: {
    flexDirection: 'row',
  },
  profile: {
    flexDirection: 'column',
    alignItems: 'center',
    width: widthPercentageToDP('18%'),
  },
  heading: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
    paddingVertical: 5,
    marginHorizontal: 10,
  },
  username: {
    textAlign: 'center',
    fontFamily: 'GothamLight',
    fontSize: 16,
  },
  allUser: {
    marginVertical: 10,
  },
  userContainer: {
    borderRadius: 6,
    width: '95%',
    alignSelf: 'center',
    elevation: 3,
    backgroundColor: 'white',
    padding: 10,
    flexDirection: 'row',
    marginVertical: 5,
    alignItems: 'center',
  },

  usertext: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
  },
  descContainer: {
    flexDirection: 'column',
    marginHorizontal: 18,
  },
  desc: {
    fontFamily: 'GothamLight',
    fontSize: 16,
  },
  emptyContainer: {
    marginHorizontal: 8,
  },
  margin: {
    height: 50,
  },
});

export default Discover;
