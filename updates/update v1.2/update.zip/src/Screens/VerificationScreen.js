import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {db, dbTimeStamp, uploadPic, usersCol} from '../Utils/Utils';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Icon from 'react-native-vector-icons/Ionicons';
import RoundButton from '../Modules/RoundButton';
import auth from '@react-native-firebase/auth';
import {launchImageLibrary} from 'react-native-image-picker';

const VerificationScreen = (props) => {
  const [isVerificationScreen, setIsVerificationScreen] = useState(false);
  const [message, setMessage] = useState('');
  const [image, setImage] = useState('');
  const [id, setId] = useState('');
  const [error, setError] = useState(null);
  const [name, setName] = useState('');
  const [successMessage, setSuccessMessage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const options = {
    mediaType: 'photo',
    maxWidth: 1920,
    maxHeight: 1080,
  };

  const imageHandler = async (response) => {
    if (!response.didCancel) {
      setImage(response.uri);
    }
  };

  const idHandler = async (response) => {
    if (!response.didCancel) {
      setId(response.uri);
    }
  };

  const verificationSubmit = async () => {
    setError(null);
    setSuccessMessage(null);
    if (!name || !id || !image) {
      setError('All Fields are required');
    } else {
      setIsLoading(true);
      try {
        const profileImage = await uploadPic(
          `verificationRequest/${auth().currentUser.uid}/profileImage`,
          image,
        );
        const idImage = await uploadPic(
          `verificationRequest/${auth().currentUser.uid}/idPic`,
          id,
        );
        if (profileImage && idImage) {
          const user = await usersCol.doc(auth().currentUser.uid).get();
          await db
            .collection('verificationRequests')
            .doc(auth().currentUser.uid)
            .set(
              {
                userid: auth().currentUser.uid,
                name: name,
                message: message,
                profileImage: profileImage,
                profilePic: auth().currentUser.photoURL,
                idImage: idImage,
                onesignalId: user.data()?.onesignalId,
                createdAt: dbTimeStamp,
              },
              {
                merge: true,
              },
            );
          setSuccessMessage(
            "Your request received successfully, we'll review soon.",
          );
        }
      } catch (err) {
        console.log('Error => ', err);
      }
      setIsLoading(false);
    }
  };

  if (isVerificationScreen) {
    return (
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.verificationBody}>
        <Text style={styles.verificationHeading}>
          We made verification simple, just fill out the form below, and we'll
          review your verification request, and provide you verified badge once
          we review your request.
        </Text>
        <TextInput
          placeholder="Full Name"
          style={styles.input}
          onChangeText={(val) => setName(val)}
          autoCompleteType="name"
          textContentType="name"
        />
        <TextInput
          multiline
          autoCorrect={false}
          style={styles.textArea}
          maxLength={135}
          placeholder="Message"
          onChangeText={(val) => setMessage(val)}
        />
        <Text style={styles.characterLeft}>{135 - message.length}</Text>
        <Text style={styles.title}>Upload Documents</Text>
        <Pressable
          style={styles.imageContainer}
          onPress={() => launchImageLibrary(options, imageHandler)}>
          {!!image && <Image source={{uri: image}} style={styles.image} />}
          {!image && (
            <View>
              <View style={styles.icon}>
                <Icon name="person" color="#fff" size={28} />
              </View>
              <Text style={styles.optionText}>Your personal picture</Text>
            </View>
          )}
        </Pressable>
        <Pressable
          style={styles.imageContainer}
          onPress={() => launchImageLibrary(options, idHandler)}>
          {!!id && <Image source={{uri: id}} style={styles.image} />}
          {!id && (
            <View>
              <View style={styles.icon}>
                <Icon name="document-text" color="#fff" size={28} />
              </View>
              <Text style={styles.optionText}>
                Copy of your passport or ID card
              </Text>
            </View>
          )}
        </Pressable>
        {!!error && <CenterText text={error} />}
        {!!successMessage && (
          <CenterText text={successMessage} textStyle={styles.success} />
        )}
        <RoundButton
          title="Send"
          onPress={() => verificationSubmit()}
          isLoading={isLoading}
        />
        <View style={styles.margin} />
      </ScrollView>
    );
  }
  return (
    <View style={styles.body}>
      <ScrollView style={styles.container}>
        <Text style={styles.heading}>Apply for Verification</Text>
        <Text style={styles.desc}>
          A verified badge is a check that appears next to the account's name to
          indicate that the account is the authentic and real.
        </Text>
        <Text style={styles.desc}>
          {'\n'}Submitting a request for verification does not guarantee that
          your account will be verified.
        </Text>
        <Text style={styles.heading}>{'\n'}How to apply?</Text>
        <View style={styles.detailContainer}>
          <Text style={styles.title}>Scan your ID</Text>
          <Text style={styles.titleDesc}>
            Have your photo ID, Passport or driver's license ready.
          </Text>
          <Text style={styles.title}>A Selfie</Text>
          <Text style={styles.titleDesc}>A selfie with your ID.</Text>
        </View>
        <Text style={styles.optionText}>
          Or you can update to pro, to get a verified badge on your account
        </Text>
        <RoundButton
          title="Get Pro"
          containerStyle={styles.button}
          icon
          iconName="rocket-outline"
          iconSize={20}
          iconColor="#fff"
          iconStyle={styles.buttonIco}
          onPress={() => props.navigation.navigate('PackageScreen')}
        />
        <Text style={styles.optionText}>Or</Text>
        <RoundButton
          title="Verify Now"
          onPress={() => setIsVerificationScreen(true)}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginHorizontal: 10,
    height: '100%',
  },
  scroll: {
    flex: 1,
    backgroundColor: '#fff',
  },
  body: {
    flex: 1,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 25,
    fontFamily: 'GothamMedium',
    color: Colors.primary,
  },
  desc: {
    color: Colors.placeholderColor,
    fontSize: 22,
    lineHeight: 19,
    letterSpacing: 1,
    fontFamily: 'GothamLight',
  },
  title: {
    fontSize: 18,
    fontFamily: 'GothamMedium',
    color: Colors.primary,
  },
  detailContainer: {
    marginVertical: heightPercentageToDP('3%'),
    marginHorizontal: widthPercentageToDP('15%'),
  },
  titleDesc: {
    color: '#B1B5B8',
    marginVertical: 4,
    fontSize: 15,
    fontFamily: 'GothamMedium',
  },
  optionText: {
    fontSize: 17,
    color: Colors.primary,
    textAlign: 'center',
    fontFamily: 'GothamMedium',
    marginVertical: 8,
  },
  button: {
    backgroundColor: Colors.proButton,
  },
  buttonIco: {
    marginHorizontal: 6,
  },
  verifyButton: {
    width: '90%',
  },
  verificationHeading: {
    fontFamily: 'GothamLight',
    fontSize: 21,
    color: Colors.primary,
    marginHorizontal: 10,
    lineHeight: 25,
  },
  verificationBody: {
    backgroundColor: '#fff',
    marginBottom: 40,
  },
  input: {
    borderWidth: 1,
    borderColor: '#8e8e8e',
    width: widthPercentageToDP('94%'),
    alignSelf: 'center',
    borderRadius: 8,
    position: 'relative',
    top: 10,
    marginBottom: 10,
    fontFamily: 'GothamLight',
    fontSize: 20,
  },
  textArea: {
    textAlignVertical: 'top',
    borderWidth: 1,
    width: widthPercentageToDP('94%'),
    alignSelf: 'center',
    borderRadius: 12,
    position: 'relative',
    height: heightPercentageToDP('18%'),
    borderColor: '#8e8e8e',
    fontFamily: 'GothamLight',
    fontSize: 20,
    top: 10,
  },
  characterLeft: {
    textAlign: 'right',
    right: 20,
    top: 10,
    fontFamily: 'GothamMedium',
    fontSize: 18,
  },
  imageContainer: {
    width: widthPercentageToDP('90%'),
    height: 250,
    backgroundColor: '#f9f9f9',
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#efefef',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginVertical: 8,
  },
  image: {
    width: widthPercentageToDP('90%'),
    height: 250,
    borderRadius: 5,
    opacity: 0.8,
  },
  icon: {
    backgroundColor: '#607D8B',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  margin: {
    height: 60,
    marginBottom: 5,
  },
  success: {
    color: '#4F8A10',
    fontFamily: 'GothamMedium',
    fontSize: 18,
    textAlign: 'center',
  },
});

export default VerificationScreen;
