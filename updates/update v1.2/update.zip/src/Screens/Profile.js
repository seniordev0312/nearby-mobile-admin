import {
  ActivityIndicator,
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {
  AdEventType,
  InterstitialAd,
  TestIds,
} from '@react-native-firebase/admob';
import {FieldValue, db, dbTimeStamp, usersCol} from '../Utils/Utils';
import React, {useEffect, useState} from 'react';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import CenterText from '../Modules/CenterText';
import {CoinsPackages} from '../Utils/Packages';
import Colors from '../Utils/Colors';
import Config from '../Utils/Config';
import Loader from '../Modules/Loader';
import Modal from 'react-native-modal';
import {PaymentRequest} from 'react-native-payments';
import RoundButton from '../Modules/RoundButton';
import SiteConfig from '../Utils/Config';
import VerifiedBadge from '../Modules/VerifiedBadge';
import auth from '@react-native-firebase/auth';

const adUnitId = __DEV__
  ? TestIds.INTERSTITIAL
  : Platform.select({
      ios: Config.FULLSCREEN_AD.IOS,
      android: Config.FULLSCREEN_AD.ANDROID,
    });

const interstitial = InterstitialAd.createForAdRequest(adUnitId, {
  requestNonPersonalizedAdsOnly: true,
  keywords: ['fashion', 'clothing'],
});

const PaymentView = (props) => {
  return (
    <TouchableOpacity style={styles.packContainer} onPress={props.onPress}>
      <Text style={styles.packText}>{`${props.coins} Credits`}</Text>
      <Text
        style={
          styles.packText
        }>{`${SiteConfig.CURRENCY_SYMBOL}${props.price}`}</Text>
    </TouchableOpacity>
  );
};

const MessagesScreen = (props) => {
  const user = auth().currentUser;
  const [isLoading, setIsLoading] = useState(true);
  const [dbUser, setDbUser] = useState(null);
  const [profileLoading, setProfileLoading] = useState(true);
  const [isCreditModal, setIsCreditModal] = useState(false);
  const [error, setError] = useState(null);
  const [loadAd, setLoadedAd] = useState(false);

  useEffect(() => {
    let isMounted = true;

    const getUser = () => {
      if (isMounted) {
        usersCol.doc(user.uid).onSnapshot(async (snap) => {
          setDbUser(snap.data());
          props.navigation.setParams({credit: snap.data().credit});
          setIsLoading(false);
        });
      }
    };

    getUser();

    return () => {
      isMounted = false;
    };
  }, [user, props.navigation]);

  useEffect(() => {
    const eventListener = interstitial.onAdEvent((type) => {
      if (type === AdEventType.LOADED) {
        setLoadedAd(true);
      }
      if (type === AdEventType.CLOSED) {
        setLoadedAd(false);
      }
    });

    // Start loading the interstitial straight away
    interstitial.load();

    // Unsubscribe from events on unmount
    return () => {
      eventListener();
    };
  }, []);

  if (loadAd) {
    interstitial.show();
  }

  const payHandler = (price, coins) => {
    const methodData = [
      {
        supportedMethods: ['apple-pay'],
        data: {
          merchantIdentifier: 'merchant.com.your-app.namespace',
          supportedNetworks: ['visa', 'mastercard', 'amex'],
          countryCode: 'US',
          currencyCode: 'USD',
          paymentMethodTokenizationParameters: {
            parameters: {
              gateway: 'stripe',
              'stripe:publishableKey': SiteConfig.STRIPE_KEY,
            },
          },
        },
      },
      {
        supportedMethods: ['android-pay'],
        data: {
          supportedNetworks: ['visa', 'mastercard', 'amex'],
          currencyCode: 'USD',
          environment: 'TEST', // Change it in production when you release your app.
          paymentMethodTokenizationParameters: {
            tokenizationType: 'GATEWAY_TOKEN',
            parameters: {
              gateway: 'stripe',
              publicKey: SiteConfig.STRIPE_KEY,
            },
          },
        },
      },
    ];
    const displayItems = [
      {
        label: `${coins} Coins`,
        amount: {
          currency: SiteConfig.CURRENCY_CODE,
          value: price,
        },
      },
    ];
    const total = {
      label: 'Total',
      amount: {
        currency: SiteConfig.CURRENCY_CODE,
        value: price,
      },
    };
    const details = {
      displayItems,
      total,
    };

    const paymentRequest = new PaymentRequest(methodData, details);
    paymentRequest
      .show()
      .then(async (paymentResponse) => {
        const {
          transactionIdentifier,
          paymentData,
          paymentToken,
          getPaymentToken,
        } = paymentResponse.details;
        let androidToken = await getPaymentToken();
        if (paymentToken || androidToken) {
          await paymentResponse.complete('success');
          await db
            .collection('payments')
            .doc(auth().currentUser.uid)
            .set({
              token: paymentToken,
              username: auth().currentUser.displayName,
              userid: auth().currentUser.uid,
              createdOn: dbTimeStamp,
              purchased: `${coins} Coins`,
              paid: price,
              paymentData: paymentData,
              identifier: transactionIdentifier,
              androidPay: androidToken,
            })
            .then(() => {
              usersCol.doc(auth().currentUser.uid).update({
                credit: FieldValue.increment(coins),
              });
            })
            .then(() => {
              props.navigation.navigate('Profile');
            });
        } else {
          setError('Error occured while processing payment');
        }
      })
      .catch((err) => {
        if (err === 409) {
          return false;
        }
      });
  };

  if (isLoading) {
    return <Loader />;
  }

  return (
    <View style={styles.container}>
      <View style={styles.profileDetails}>
        <View style={styles.profileShadow}>
          {!!profileLoading && (
            <ActivityIndicator size="large" color={Colors.primary} />
          )}
          <Image
            source={{uri: user.photoURL}}
            style={styles.profilePic}
            onLoadEnd={() => setProfileLoading(false)}
          />
          {!!dbUser?.isVerified && (
            <VerifiedBadge size={20} style={styles.verifyBadge} />
          )}
        </View>
        <Text style={styles.username}>{user.displayName}</Text>
        {!!dbUser?.bio && (
          <Text style={styles.bio}>{`${dbUser?.bio.replace(
            '\\n',
            '\n',
          )}`}</Text>
        )}
        <View style={styles.actionButtonContainer}>
          {!dbUser?.isVerified && (
            <RoundButton
              title="Get Verified"
              containerStyle={styles.verifyButton}
              onPress={() => props.navigation.navigate('VerificationScreen')}
            />
          )}
          <RoundButton
            title="Buy Credit"
            containerStyle={styles.verifyButton}
            onPress={() => setIsCreditModal(true)}
          />
          <Modal
            isVisible={isCreditModal}
            style={styles.modal}
            onBackdropPress={() => setIsCreditModal(false)}
            onBackButtonPress={() => setIsCreditModal(false)}>
            <View style={styles.modalContainer}>
              <Text style={styles.modalHeading}>Buy Credits</Text>
              <Text style={styles.desc}>
                Credits are like cash, you can send it to your friends/family,
                and can withdraw any time.
              </Text>
              {CoinsPackages?.map((pkg) => (
                <PaymentView
                  key={pkg?.id}
                  coins={pkg?.coins}
                  price={pkg?.price}
                  onPress={() => payHandler(pkg?.price, pkg?.coins)}
                />
              ))}
              {!!error && <CenterText text={error} />}
            </View>
          </Modal>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
  },
  profileDetails: {
    top: heightPercentageToDP('6%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
  },
  profilePic: {
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  profileShadow: {
    width: 200,
    height: 200,
    borderRadius: 100,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
    elevation: 2,
  },
  username: {
    fontSize: 18,
    marginVertical: 8,
    fontFamily: 'GothamMedium',
  },
  bio: {
    fontFamily: 'GothamLight',
    fontSize: 20,
    marginVertical: 8,
  },
  verifyButton: {
    backgroundColor: Colors.secondary,
    borderRadius: 6,
    width: '40%',
    height: 50,
    marginHorizontal: 10,
  },
  actionButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  verifyBadge: {
    position: 'absolute',
    top: heightPercentageToDP('22%'),
    right: widthPercentageToDP('10%'),
  },
  modal: {
    margin: 0,
    justifyContent: 'flex-end',
  },
  modalContainer: {
    backgroundColor: '#fff',
    height: '50%',
    width: '100%',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
    paddingHorizontal: 20,
  },
  modalHeading: {
    fontSize: 22,
    fontFamily: 'GothamMedium',
    textAlign: 'center',
  },
  desc: {
    fontSize: 20,
    color: '#8e8e8e',
    fontFamily: 'GothamLight',
  },
  packContainer: {
    borderRadius: 6,
    width: '100%',
    elevation: 3,
    backgroundColor: 'white',
    height: 50,
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  packText: {
    fontFamily: 'GothamMedium',
    fontSize: 17,
  },
});

export default MessagesScreen;
