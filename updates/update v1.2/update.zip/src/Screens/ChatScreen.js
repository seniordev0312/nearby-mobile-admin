import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {
  AdEventType,
  InterstitialAd,
  TestIds,
} from '@react-native-firebase/admob';
import Animated, {Easing} from 'react-native-reanimated';
import {
  Bubble,
  Composer,
  GiftedChat,
  InputToolbar,
  Send,
} from 'react-native-gifted-chat';
import {FieldValue, db, timeStamp, uploadPic} from '../Utils/Utils';
import React, {useCallback, useEffect, useState} from 'react';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import Colors from '../Utils/Colors';
import Icon from 'react-native-vector-icons/Ionicons';
import ImageView from 'react-native-image-viewing';
import Images from '../Modules/ImageAdder';
import Loader from '../Modules/Loader';
import Modal from 'react-native-modal';
import OneSignal from 'react-native-onesignal';
import PressableText from '../Modules/PressableText';
import SiteConfig from '../Utils/Config';
import auth from '@react-native-firebase/auth';

const adUnitId = __DEV__
  ? TestIds.INTERSTITIAL
  : Platform.select({
      ios: SiteConfig.FULLSCREEN_AD.IOS,
      android: SiteConfig.FULLSCREEN_AD.ANDROID,
    });

const interstitial = InterstitialAd.createForAdRequest(adUnitId, {
  requestNonPersonalizedAdsOnly: true,
  keywords: ['fashion', 'clothing'],
});

const ChatScreen = (props) => {
  const {userid, onesignalId, username, dp} = props.route.params;
  const myOneSignalId = OneSignal.getDeviceState();
  const [messages, setMessages] = useState([]);
  const [sending, setSending] = useState(false);
  const [image, setImage] = useState('');
  const [pickerModal, setPickerModal] = useState(false);
  const [error, setError] = useState(null);
  const [animModal, setAnimModal] = useState(false);
  const [animValue] = useState(new Animated.Value(1));
  const [imageModal, setImageModal] = useState(false);
  const [currentImage, setCurrentImage] = useState();
  const [loadAd, setLoadedAd] = useState(false);
  const node = useCallback(() => {
    if (userid > auth().currentUser.uid) {
      return userid + auth().currentUser.uid;
    } else {
      return auth().currentUser.uid + userid;
    }
  }, [userid]);

  useEffect(() => {
    const unsubscribe = db
      .collection('messages')
      .doc(node())
      .onSnapshot((snap) => {
        if (snap.exists) {
          if (messages.length === 0) {
            setMessages(GiftedChat.append(messages, snap.data().message));
          } else {
            snap.data().message.map((data) => {
              if (!messages.some((msgData) => msgData._id === data._id)) {
                setMessages(GiftedChat.prepend(messages, data));
              }
            });
          }
        }
      });

    //Unsubscribe due to memory leak
    return () => unsubscribe();
  }, [messages, node]);

  useEffect(() => {
    const eventListener = interstitial.onAdEvent((type) => {
      if (type === AdEventType.LOADED) {
        setLoadedAd(true);
      }
      if (type === AdEventType.CLOSED) {
        setLoadedAd(false);
      }
    });

    // Start loading the interstitial straight away
    interstitial.load();

    // Unsubscribe from events on unmount
    return () => {
      eventListener();
    };
  }, []);

  if (loadAd) {
    interstitial.show();
  }

  const fadeOut = () => {
    Animated.timing(animValue, {
      toValue: 0,
      duration: 2000,
      easing: Easing.linear,
    }).start();
    animValue.setValue(1);
  };

  const options = {
    mediaType: 'photo',
    maxWidth: 480,
    maxHeight: 480,
  };

  const messageHandler = async (msgs = []) => {
    let uploadedImage;
    if (image) {
      setSending(true);
      try {
        uploadedImage = await uploadPic(`/chat/images/${msgs[0]._id}`, image);
        setImage(null);
      } catch (err) {
        setError('Error occurred ', err.message);
      }
    }
    const msg = [
      {
        _id: msgs[0]._id,
        text: msgs[0].text,
        createdAt: new Date(),
        user: {
          _id: auth().currentUser.uid,
          avatar: auth().currentUser.photoURL,
        },
        image: uploadedImage,
      },
    ];
    setMessages(GiftedChat.prepend(messages, msg));
    setSending(true);
    try {
      await db
        .collection('messages')
        .doc(node())
        .set(
          {
            message: FieldValue.arrayUnion({
              _id: msgs[0]._id,
              text: msgs[0].text,
              createdAt: timeStamp.now().toMillis(),
              user: {
                _id: auth().currentUser.uid,
                avatar: auth().currentUser.photoURL,
              },
              image: uploadedImage,
            }),
          },
          {
            merge: true,
          },
        )
        .then(async () => {
          await db
            .collection('recentMessages')
            .doc(auth().currentUser.uid)
            .set(
              {
                [userid]: {
                  _id: userid,
                  text: msgs[0].text,
                  createdAt: FieldValue.serverTimestamp(),
                  image: uploadedImage,
                  profilePic: dp,
                  onesignalId: onesignalId,
                  username: username,
                  read: false,
                },
              },
              {
                merge: true,
              },
            );
        })
        .then(async () => {
          db.collection('recentMessages')
            .doc(userid)
            .set(
              {
                [auth().currentUser.uid]: {
                  _id: auth().currentUser.uid,
                  text: msgs[0].text,
                  createdAt: FieldValue.serverTimestamp(),
                  image: uploadedImage,
                  profilePic: auth().currentUser.photoURL,
                  username: auth().currentUser.displayName,
                  onesignalId: await myOneSignalId.userId,
                  read: false,
                },
              },
              {
                merge: true,
              },
            );
        })
        .then(async () => {
          setSending(false);
          const notificationObj = {
            contents: msgs[0].text ? {en: msgs[0].text} : {en: 'Photo'},
            headings: {en: auth().currentUser.displayName},
            data: {
              userid: auth().currentUser.uid,
              dp: auth().currentUser.photoURL,
              username: auth().currentUser.displayName,
              onesignalId: myOneSignalId.userId,
            },
            app_url: `nearby://chat/${
              auth().currentUser.uid
            }/${encodeURIComponent(
              auth().currentUser.photoURL,
            )}/${encodeURIComponent(auth().currentUser.displayName)}/${
              myOneSignalId.userId
            }`,
            big_picture: uploadedImage ? uploadedImage : null,
            large_icon: auth().currentUser.photoURL,
            include_player_ids: [onesignalId],
          };
          const json = JSON.stringify(notificationObj);
          OneSignal.postNotification(
            json,
            (success) => {
              console.log('Sent => ', success);
            },
            (err) => {
              console.log('Error => ', err);
            },
          );
        });
    } catch (err) {
      setError('Error ', err.message);
      setAnimModal(true);
      fadeOut();
      setSending(false);
    }
  };

  const imageHandler = async (response) => {
    if (!response.didCancel) {
      setImage(response.uri);
      setPickerModal(false);
    }
  };

  const customSendPress = (text, onSend) => {
    if (image && !text && onSend) {
      onSend({text: text.trim()}, true);
    } else if (text && onSend) {
      onSend({text: text.trim()}, true);
      0;
    } else {
      return false;
    }
  };

  const customActions = (actionProps) => {
    return (
      <TouchableOpacity
        style={styles.actionContainer}
        onPress={() => setPickerModal(true)}>
        <Icon name="camera" color={Colors.primary} size={32} />
      </TouchableOpacity>
    );
  };

  const customInput = (customProps) => {
    return (
      <InputToolbar {...customProps} containerStyle={styles.inputStyles} />
    );
  };

  const customSend = ({onSend, text, sendButtonProps, ...sendProps}) => {
    return (
      <View style={styles.sendButtonContainer}>
        <Send
          {...sendProps}
          sendButtonProps={{
            ...sendButtonProps,
            onPress: () => (sending ? null : customSendPress(text, onSend)),
          }}>
          <View style={styles.button}>
            {sending ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Icon name="paper-plane-outline" size={22} color="#fff" />
            )}
          </View>
        </Send>
      </View>
    );
  };

  const customTicks = (currentMessage) => {
    return (
      <View style={styles.tickView}>
        {!!currentMessage.pending && (
          <Icon
            style={styles.tick}
            name="time-outline"
            size={16}
            color="#fff"
          />
        )}
        {!!currentMessage.received && <Text style={styles.tick}>✓</Text>}
      </View>
    );
  };

  const customComposer = (compProps) => {
    return <Composer {...compProps} textInputStyle={styles.input} />;
  };

  const customFooter = (footerProps) => {
    return (
      <View style={styles.footerContainer}>
        {!!image && (
          <View style={styles.footerBottom}>
            <Images source={{uri: image}} onPress={() => setImage(null)} />
          </View>
        )}
        <View style={styles.bottom} />
      </View>
    );
  };

  const customBubble = (bubblePropos) => {
    return (
      <Bubble
        {...bubblePropos}
        textStyle={{
          left: {
            color: Colors.primary,
            fontFamily: 'GothamMedium',
            fontSize: 16,
          },
          right: {
            fontFamily: 'Poppins-Medium',
            fontSize: 15,
          },
        }}
        wrapperStyle={{
          right: {
            borderRadius: 12,
          },
        }}
      />
    );
  };

  const customImage = (imageProps) => {
    return (
      <View>
        <Pressable
          style={styles.imageContainer}
          onPress={() => {
            setCurrentImage(imageProps?.currentMessage.image);
            setImageModal(true);
          }}>
          <Image
            source={{uri: imageProps?.currentMessage.image}}
            style={styles.image}
          />
        </Pressable>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <GiftedChat
        messages={messages}
        onSend={(msg) => messageHandler(msg)}
        user={{
          _id: auth().currentUser.uid,
        }}
        renderBubble={customBubble}
        renderComposer={customComposer}
        renderSend={customSend}
        alwaysShowSend
        placeholder={image ? 'Add Caption' : 'Type your message'}
        renderActions={customActions}
        renderInputToolbar={customInput}
        renderChatFooter={customFooter}
        renderMessageImage={customImage}
        inverted={false}
        renderLoading={() => {
          return <Loader />;
        }}
        renderTicks={customTicks}
      />
      {!!animModal && (
        <Animated.View
          style={{...styles.animModalContainer, opacity: animValue}}>
          <Text style={styles.requestText}>{error}</Text>
        </Animated.View>
      )}
      <ImageView
        images={[{uri: currentImage}]}
        imageIndex={0}
        visible={imageModal}
        onRequestClose={() => {
          setCurrentImage(null);
          setImageModal(false);
        }}
      />
      <Modal
        isVisible={pickerModal}
        style={styles.view}
        onBackButtonPress={() => setPickerModal(false)}
        onBackdropPress={() => setPickerModal(false)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalLine} />
          <Text style={styles.text}>Select</Text>
          <PressableText
            style={styles.modalButton}
            textStyle={styles.modalButtonText}
            icon={true}
            iconName="camera-outline"
            iconSize={32}
            iconColor={Colors.primary}
            text="Take Photo"
            onPress={() => launchCamera(options, imageHandler)}
          />
          <PressableText
            icon={true}
            style={styles.modalButton}
            textStyle={styles.modalButtonText}
            iconName="image-outline"
            iconSize={32}
            iconColor={Colors.primary}
            text="Choose from Gallery"
            onPress={() => launchImageLibrary(options, imageHandler)}
          />
        </View>
      </Modal>
      <View style={styles.margin} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  inputStyles: {
    marginHorizontal: 8,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    borderTopWidth: 0,
    backgroundColor: '#efefef',
    fontFamily: 'GothamMedium',
  },
  actionContainer: {
    alignSelf: 'center',
    marginLeft: 10,
  },
  input: {
    fontFamily: 'GothamLight',
    fontSize: 20,
  },
  view: {
    margin: 0,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'white',
    height: '15%',
    width: '95%',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    justifyContent: 'center',
    alignItems: 'stretch',
  },
  modalButton: {
    alignItems: 'center',
    flexDirection: 'row',
    marginLeft: 20,
  },
  text: {
    fontSize: 18,
    color: Colors.primary,
    textAlign: 'center',
    marginBottom: 8,
    fontFamily: 'GothamMedium',
  },
  modalButtonText: {
    fontSize: 22,
    marginLeft: 12,
    fontFamily: 'GothamLight',
  },
  footerContainer: {
    justifyContent: 'flex-end',
  },
  footerBottom: {
    bottom: 0,
  },
  bottom: {
    marginBottom: 0,
  },
  footerImage: {
    width: 40,
    height: 40,
    borderRadius: 6,
  },
  tick: {
    backgroundColor: 'transparent',
  },
  tickView: {
    flexDirection: 'row',
    marginRight: 10,
  },
  margin: {
    marginBottom: 8,
  },
  sendButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    marginBottom: 2,
  },
  button: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.primary,
    width: 40,
    height: 40,
    borderRadius: 22,
  },
  imageContainer: {
    width: 200,
    height: 200,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 195,
    height: 195,
    borderRadius: 8,
  },
});

export default ChatScreen;
