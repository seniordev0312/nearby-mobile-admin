import {
  AdEventType,
  InterstitialAd,
  TestIds,
} from '@react-native-firebase/admob';
import {
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import {ProfilePic, uploadPic, usersCol} from '../Utils/Utils';
import React, {useEffect, useState} from 'react';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Icon from 'react-native-vector-icons/Ionicons';
import Loader from '../Modules/Loader';
import Modal from 'react-native-modal';
import PressableText from '../Modules/PressableText';
import RoundButton from '../Modules/RoundButton';
import SiteConfig from '../Utils/Config';
import auth from '@react-native-firebase/auth';

const adUnitId = __DEV__
  ? TestIds.INTERSTITIAL
  : Platform.select({
      ios: SiteConfig.FULLSCREEN_AD.IOS,
      android: SiteConfig.FULLSCREEN_AD.ANDROID,
    });

const interstitial = InterstitialAd.createForAdRequest(adUnitId, {
  requestNonPersonalizedAdsOnly: true,
  keywords: ['fashion', 'clothing'],
});

const SettingsScreen = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const [pickerModal, setPickerModal] = useState(false);
  const [loggedUser, setLoggedUser] = useState('');
  const [image, setImage] = useState('');
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [error, setError] = useState(null);
  const [upLoading, setUpLoading] = useState(false);
  const [loadAd, setLoadedAd] = useState(false);
  useEffect(() => {
    let isMounted = true;

    const fetchFeaturedUsers = async () => {
      const data = await usersCol.doc(auth().currentUser.uid).get();
      if (isMounted) {
        setLoggedUser(data.data());
        setIsLoading(false);
      }
    };

    fetchFeaturedUsers();

    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    const eventListener = interstitial.onAdEvent((type) => {
      if (type === AdEventType.LOADED) {
        setLoadedAd(true);
      }
      if (type === AdEventType.CLOSED) {
        setLoadedAd(false);
      }
    });

    // Start loading the interstitial straight away
    interstitial.load();

    // Unsubscribe from events on unmount
    return () => {
      eventListener();
    };
  }, []);

  if (loadAd) {
    interstitial.show();
  }

  const updateHandler = async () => {
    const userRef = usersCol.doc(auth().currentUser.uid);
    //Nothing Changed, i.e., name, bio and profile is same;
    if (!name && !image && !bio) {
      props.navigation.goBack();
      //If one or all inputs are/is changed, else is same.
    } else {
      //If only name is updated;
      if (
        !image &&
        (bio === loggedUser?.bio || !bio) &&
        name !== loggedUser?.name &&
        name.length !== 0
      ) {
        setUpLoading(true);
        try {
          userRef
            .update({
              name: name,
            })
            .then(() => {
              auth().currentUser.updateProfile({
                displayName: name,
              });
            });
        } catch (err) {
          setError('Unexpected error while updating profile');
        }
        setUpLoading(false);
      }
      //Else if only bio is updated.....
      else if (
        (!name || name === loggedUser?.name) &&
        !image &&
        bio !== loggedUser?.bio &&
        bio.length !== 0
      ) {
        setUpLoading(true);
        try {
          userRef
            .update({
              bio: bio,
            })
            .then(() => {
              props.navigation.goBack();
            });
        } catch (err) {
          setError('Unexpected error while updating profile');
        }
        setUpLoading(false);

        //If profile avtar is changed only//
      } else if (
        (!name || name === loggedUser?.name) &&
        (!bio || bio === loggedUser?.bio) &&
        image
      ) {
        setUpLoading(true);
        try {
          const storageImage = await uploadPic(
            ProfilePic(auth().currentUser.uid),
            image,
          );
          userRef
            .update({
              profileAvtar: storageImage,
            })
            .then(() => {
              auth().currentUser.updateProfile({
                photoURL: storageImage,
              });
            });
        } catch (err) {
          setError('Unexpected error while updating profile');
        }
        setUpLoading(false);
        //If bio and name change occured;
      } else if (
        bio &&
        bio !== loggedUser?.bio &&
        name &&
        name !== loggedUser?.name &&
        !image &&
        bio.length !== 0 &&
        name.length !== 0
      ) {
        setUpLoading(true);
        try {
          userRef
            .update({
              name: name,
              bio: bio,
            })
            .then(() => {
              auth().currentUser.updateProfile({
                displayName: name,
              });
            })
            .then(() => {
              props.navigation.goBack();
            });
        } catch (err) {
          setError('Unexpected error while updating profile');
        }
        //If name and profile is changed;
      } else if (
        name &&
        name !== loggedUser?.name &&
        name.length !== 0 &&
        image &&
        (!bio || bio === loggedUser?.bio)
      ) {
        setUpLoading(true);
        try {
          const storageImage = await uploadPic(
            ProfilePic(auth().currentUser.uid),
            image,
          );
          userRef
            .update({
              name: name,
              profileAvtar: storageImage,
            })
            .then(() => {
              auth()
                .currentUser.updateProfile({
                  displayName: name,
                  photoURL: storageImage,
                })
                .then(() => props.navigation.goBack());
            });
        } catch (err) {
          setError('Unexpected error while updating profile');
        }
        setUpLoading(false);
        //Bio and Profile is changed;
      } else if (
        bio &&
        bio !== loggedUser?.bio &&
        bio.length !== 0 &&
        image &&
        (!name || name === loggedUser?.name)
      ) {
        setUpLoading(true);
        try {
          const storageImage = await uploadPic(
            ProfilePic(auth().currentUser.uid),
            image,
          );
          userRef
            .update({
              bio: bio,
              profileAvtar: storageImage,
            })
            .then(() => {
              auth()
                .currentUser.updateProfile({
                  photoURL: storageImage,
                })
                .then(() => props.navigation.goBack());
            });
        } catch (err) {
          setError('Unexpected error while updating profile');
        }
        setUpLoading(false);
      } else {
        setUpLoading(true);
        try {
          const storageImage = await uploadPic(
            ProfilePic(auth().currentUser.uid),
            image,
          );
          userRef
            .update({
              name: name,
              bio: bio,
              profileAvtar: storageImage,
            })
            .then(() => {
              auth()
                .currentUser.updateProfile({
                  displayName: name,
                  photoURL: storageImage,
                })
                .then(() => props.navigation.goBack());
            });
        } catch (err) {
          setError('Unexpected error while updating profile');
        }
      }
    }
  };

  const options = {
    mediaType: 'photo',
    maxWidth: 480,
    maxHeight: 480,
  };

  const imageHandler = async (response) => {
    if (!response.didCancel) {
      setImage(response.uri);
      setPickerModal(false);
    }
  };

  if (isLoading) {
    return <Loader />;
  }

  return (
    <KeyboardAvoidingView style={styles.container}>
      <ScrollView>
        <View style={styles.body}>
          <Pressable
            style={styles.profileCover}
            onPress={() => setPickerModal(true)}>
            {!image && (
              <Icon
                name="add-outline"
                size={64}
                color="#fff"
                style={styles.absolute}
              />
            )}
            <Image
              source={{uri: image ? image : loggedUser?.profileAvtar}}
              style={styles.profileAvtar}
            />
          </Pressable>
          <TextInput
            onChangeText={(val) => setName(val)}
            style={styles.input}
            placeholder="Name">
            {loggedUser?.name}
          </TextInput>
          <TextInput
            onChangeText={(val) => setBio(val)}
            style={styles.input}
            multiline
            maxLength={135}
            placeholder="Bio">
            {loggedUser?.bio}
          </TextInput>
          <Text style={styles.characterLeft}>{135 - bio.length}</Text>
        </View>
        <RoundButton
          title="Update"
          onPress={() => updateHandler()}
          isLoading={upLoading}
        />
        <View style={styles.margin} />
        <Modal
          isVisible={pickerModal}
          style={styles.view}
          onBackButtonPress={() => setPickerModal(false)}
          onBackdropPress={() => setPickerModal(false)}>
          <View style={styles.modalContainer}>
            <View style={styles.modalLine} />
            <Text style={styles.text}>Select</Text>
            <PressableText
              style={styles.modalButton}
              textStyle={styles.modalButtonText}
              icon={true}
              iconName="camera-outline"
              iconSize={32}
              iconColor={Colors.primary}
              text="Take Photo"
              onPress={() => launchCamera(options, imageHandler)}
            />
            <PressableText
              icon={true}
              style={styles.modalButton}
              textStyle={styles.modalButtonText}
              iconName="image-outline"
              iconSize={32}
              iconColor={Colors.primary}
              text="Choose from Gallery"
              onPress={() => launchImageLibrary(options, imageHandler)}
            />
          </View>
          {!!error && <CenterText text={error} />}
        </Modal>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f8f9fc',
    flex: 1,
  },
  body: {
    marginVertical: 35,
  },
  profileCover: {
    width: 200,
    height: 200,
    backgroundColor: Colors.primary,
    borderRadius: 100,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    opacity: 0.7,
    elevation: 2,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  profileAvtar: {
    width: 200,
    height: 200,
    borderRadius: 100,
    alignSelf: 'center',
  },
  input: {
    fontFamily: 'GothamMedium',
    fontSize: 18,
    borderBottomColor: '#677483',
    borderBottomWidth: 2,
    width: '90%',
    alignSelf: 'center',
    marginVertical: 10,
  },
  characterLeft: {
    textAlign: 'right',
    right: 20,
    fontFamily: 'GothamMedium',
    fontSize: 18,
  },
  margin: {
    height: 60,
    marginBottom: 5,
  },
  absolute: {
    position: 'absolute',
  },
  view: {
    margin: 0,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'white',
    height: '15%',
    width: '95%',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    justifyContent: 'center',
    alignItems: 'stretch',
  },
  modalButton: {
    alignItems: 'center',
    flexDirection: 'row',
    marginLeft: 20,
  },
  modalButtonText: {
    fontSize: 22,
    marginLeft: 12,
    fontFamily: 'GothamLight',
  },
  text: {
    fontSize: 18,
    color: Colors.primary,
    textAlign: 'center',
    marginBottom: 8,
    fontFamily: 'GothamMedium',
  },
  modalLine: {
    width: '10%',
    borderBottomWidth: 3,
    borderBottomColor: '#8e8e8e',
    alignSelf: 'center',
    marginBottom: 6,
  },
});

export default SettingsScreen;
