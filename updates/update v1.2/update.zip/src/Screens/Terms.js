import {ActivityIndicator, StyleSheet, View} from 'react-native';
import React, {useEffect, useState} from 'react';

import Colors from '../Utils/Colors';
import {WebView} from 'react-native-webview';
import {db} from '../Utils/Utils';

const OurTerms = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const [contents, setContents] = useState(null);

  useEffect(() => {
    let isMounted = true;

    const getData = () => {
      if (isMounted) {
        db.collection('termsPage')
          .doc('termsAndConditions')
          .onSnapshot(async (snap) => {
            if (snap.exists) {
              setContents(snap.data().content);
              setIsLoading(false);
            } else {
              setIsLoading(false);
            }
          });
      }
    };

    getData();

    return () => {
      isMounted = false;
    };
  });

  if (isLoading) {
    return (
      <View>
        <ActivityIndicator size="large" color={Colors.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {!!contents && (
        <WebView
          style={styles.container}
          originWhitelist={['*']}
          source={{
            html: `<html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"></head><body>${contents}</body></html>`,
          }}
        />
      )}
      <View style={styles.margin} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  margin: {
    height: 60,
    marginBottom: 5,
  },
});

export default OurTerms;
