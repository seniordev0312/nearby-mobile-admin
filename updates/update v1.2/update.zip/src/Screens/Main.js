import {
  ActivityIndicator,
  Image,
  Linking,
  PermissionsAndroid,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {BannerAd, BannerAdSize, TestIds} from '@react-native-firebase/admob';
import MapView, {Marker, PROVIDER_GOOGLE} from 'react-native-maps';
import React, {createRef, useEffect, useState} from 'react';
import {distance, usersCol} from '../Utils/Utils';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import Colors from '../Utils/Colors';
import CustomLabel from '../Modules/CustomLabel';
import Geolocation from 'react-native-geolocation-service';
import Icon from 'react-native-vector-icons/Ionicons';
import Modal from 'react-native-modal';
import MultiSlider from '@ptomasroos/react-native-multi-slider';
import PressableText from '../Modules/PressableText';
import RoundButton from '../Modules/RoundButton';
import SiteConfig from '../Utils/Config';
import auth from '@react-native-firebase/auth';
import {displayName} from '../../app.json';

const adUnitId = __DEV__
  ? TestIds.BANNER
  : Platform.select({
      ios: SiteConfig.BANNER_ADD_ID.IOS,
      android: SiteConfig.BANNER_ADD_ID.ANDROID,
    });

class UserModal {
  constructor(
    id,
    coords,
    profileAvtar,
    name,
    dateOfBirth,
    gender,
    userCoords,
    onesignalId,
  ) {
    this.id = id;
    this.coords = coords;
    this.profileAvtar = profileAvtar;
    this.name = name;
    this.age = ((dateString) => {
      var today = new Date();
      var birthDate = dateOfBirth.toDate();
      var age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      return age;
    })();
    this.gender = gender;
    this.distance = Math.trunc(
      distance(
        coords?.latitude,
        coords?.longitude,
        userCoords?.latitude,
        userCoords?.longitude,
      ) / 1000,
    );
    this.onesignalId = onesignalId;
  }
}

const MainScreen = (props) => {
  const {isFocused} = props.route.params;
  const [isLoading, setIsLoading] = useState(true);
  const [age, setAge] = useState([SiteConfig.MIN_AGE, SiteConfig.MAX_AGE]);
  const [filterDistance, setFilterDistance] = useState([SiteConfig.MAX_RANGE]);
  const [initialCords, setInitialCords] = useState({});
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [filteredProfiles, setFilteredProfiles] = useState(null);
  const [gender, setGender] = useState('');
  const [users, setUsers] = useState([]);
  const [loadAd, setLoadedAd] = useState(true);
  const [closeButton, setCloseButton] = useState(false);

  const mapView = createRef();

  useEffect(() => {
    let isMounted = true;

    if (isMounted && !initialCords?.latitude) {
      (async () => {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
            {
              title: `${displayName} wants to access location`,
              message:
                `${displayName} use the location to find` +
                'the best around you.',
              buttonNegative: 'Allow',
              buttonPositive: 'Deny',
            },
          );
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            accessLocation();
          } else {
            if (granted === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
              Linking.openSettings();
            }
          }
        } catch (err) {
          console.warn(
            'Error occured, while fetching location, contact to app administrators',
            err,
          );
        }
      })();
    }

    return () => {
      isMounted = false;
    };
  });

  useEffect(() => {
    let isMounted = true;
    if (isMounted && initialCords?.latitude) {
      const getUsers = async () => {
        const getAllUsers = await usersCol.get();
        const allUsers = getAllUsers.docs
          .filter((u) => u.id !== auth().currentUser.uid)
          .map((data) => {
            const isFound = users.find((u) => u.id === data.id);
            if (isFound) {
              return isFound;
            }
            const dbData = data.data();
            return new UserModal(
              data?.id,
              dbData?.coords,
              dbData?.profileAvtar,
              dbData?.name,
              dbData?.dateOfBirth,
              dbData?.gender,
              {
                latitude: initialCords?.latitude,
                longitude: initialCords?.longitude,
              },
              dbData?.onesignalId,
            );
          });
        setUsers(allUsers);
      };
      getUsers();
    }
    return () => {
      isMounted = false;
    };
  }, [users, initialCords]);

  const accessLocation = async () => {
    Geolocation.getCurrentPosition(
      async (position) => {
        setInitialCords({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        });
        setIsLoading(false);
      },
      (err) => {
        console.log('Error => ', err);
      },
    );
  };

  const renderMarkerOnMap = () => {
    return users?.map((user) => (
      <Marker
        onPress={() => setSelectedProfile(user)}
        key={user?.id}
        coordinate={{
          latitude: user?.coords.latitude,
          longitude: user?.coords.longitude,
        }}
        title={user?.name}>
        <View>
          <Image source={{uri: user?.profileAvtar}} style={styles.markerPic} />
        </View>
      </Marker>
    ));
  };

  const filteredMarkers = () => {
    return filteredProfiles?.map((user) => (
      <Marker
        onPress={() => setSelectedProfile(user)}
        key={user?.id}
        coordinate={{
          latitude: user?.coords.latitude,
          longitude: user?.coords.longitude,
        }}
        title={user?.name}>
        <View>
          <Image source={{uri: user?.profileAvtar}} style={styles.markerPic} />
        </View>
      </Marker>
    ));
  };

  const locateMe = () => {
    mapView.current.animateToRegion(initialCords, 1000);
  };

  if (isLoading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#000" />
      </View>
    );
  }

  const distanceBetweenUser = () => {
    const d = distance(
      initialCords.latitude,
      initialCords.longitude,
      selectedProfile.coords.latitude,
      selectedProfile.coords.longitude,
    );
    if (d <= 1000) {
      return `${Math.ceil(d)} meters`;
    } else {
      const km = Math.ceil(d / 1000);
      return `${km} KM`;
    }
  };

  const filterUsers = () => {
    const newArray = users.filter(
      (elem) =>
        elem.age >= age[0] &&
        elem.age <= age[1] &&
        elem.gender === gender &&
        elem.distance <= filterDistance,
    );
    setFilteredProfiles(newArray);
    props.navigation.setParams({isFocused: false});
  };

  const resetFilters = () => {
    setFilteredProfiles(null);
    setAge([SiteConfig.MIN_AGE, SiteConfig.MAX_AGE]);
    setFilterDistance([SiteConfig.MAX_RANGE]);
    props.navigation.setParams({isFocused: false});
  };

  return (
    <View style={styles.container}>
      <MapView
        provider={PROVIDER_GOOGLE}
        ref={mapView}
        onPress={() => setSelectedProfile(null)}
        initialRegion={initialCords}
        style={{...StyleSheet.absoluteFillObject}}
        showsMyLocationButton={false}
        showsCompass={false}
        showsUserLocation>
        {!!users && filteredProfiles === null
          ? renderMarkerOnMap()
          : filteredMarkers()}
      </MapView>
      <TouchableOpacity style={styles.locateButton} onPress={() => locateMe()}>
        <Icon name="locate-outline" size={32} color="#000" />
      </TouchableOpacity>
      {!!selectedProfile && (
        <View style={styles.selectedProfileContainer}>
          <Image
            source={{uri: selectedProfile?.profileAvtar}}
            style={styles.profilePic}
            resizeMode="cover"
          />
          <Pressable
            style={styles.margin}
            onPress={() =>
              props.navigation.navigate('Profile', {
                screen: 'UserScreen',
                params: {
                  uid: selectedProfile?.id,
                  name: selectedProfile?.name,
                },
              })
            }>
            <Text style={styles.modalText}>{selectedProfile?.name}</Text>
            <Text style={styles.desc}>{`${distanceBetweenUser()} away `}</Text>
          </Pressable>
          <Pressable
            style={styles.requestButton}
            onPress={() =>
              props.navigation.push('ChatScreen', {
                userid: selectedProfile?.id,
                username: selectedProfile?.name,
                onesignalId: selectedProfile?.onesignalId,
                dp: selectedProfile?.profileAvtar,
              })
            }>
            <Icon
              name="chatbox-ellipses-outline"
              size={28}
              color={Colors.primary}
            />
          </Pressable>
        </View>
      )}
      <View style={styles.adContainer}>
        {!!loadAd && (
          <>
            <BannerAd
              unitId={adUnitId}
              size={BannerAdSize.BANNER}
              onAdLoaded={() => setCloseButton(true)}
              requestOptions={{
                requestNonPersonalizedAdsOnly: true,
              }}
            />
            {!!closeButton && (
              <Pressable
                style={styles.closeAd}
                onPress={() => setLoadedAd(false)}>
                <Icon name="close-outline" size={24} color={Colors.primary} />
              </Pressable>
            )}
          </>
        )}
      </View>
      <Modal
        isVisible={isFocused}
        onBackButtonPress={() => props.navigation.setParams({isFocused: false})}
        onBackdropPress={() => props.navigation.setParams({isFocused: false})}
        propagateSwipe
        style={styles.modal}>
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalText}>Filters</Text>
            <PressableText
              style={styles.reset}
              text="Reset"
              textStyle={styles.modalText}
              icon
              iconName="trash-outline"
              iconSize={26}
              iconColor={Colors.primary}
              onPress={() => resetFilters()}
            />
          </View>
          <Text style={styles.filterDesc}>Distance</Text>
          <View style={styles.sliderContainer}>
            <MultiSlider
              values={filterDistance}
              sliderLength={widthPercentageToDP('70%')}
              step={1}
              min={SiteConfig.MIN_RANGE}
              max={SiteConfig.MAX_RANGE}
              customLabel={CustomLabel}
              enableLabel
              selectedStyle={styles.slideSelected}
              trackStyle={styles.sliderTrack}
              containerStyle={styles.sliderStyle}
              onValuesChangeFinish={(e) => setFilterDistance(e)}
            />
          </View>
          <Text style={styles.filterDesc}>Age</Text>
          <View style={styles.sliderContainer}>
            <MultiSlider
              values={[age[0], age[1]]}
              sliderLength={widthPercentageToDP('70%')}
              onValuesChangeFinish={(e) => setAge(e)}
              min={SiteConfig.MIN_AGE}
              max={SiteConfig.MAX_AGE}
              step={1}
              selectedStyle={styles.slideSelected}
              trackStyle={styles.sliderTrack}
              containerStyle={styles.sliderStyle}
              customLabel={CustomLabel}
              enableLabel
            />
          </View>
          <Text style={styles.filterDesc}>Gender</Text>
          <View style={styles.genderButtonContainer}>
            <Pressable onPress={() => setGender('female')}>
              <View
                // eslint-disable-next-line react-native/no-inline-styles
                style={{
                  ...styles.genderButton,
                  backgroundColor: gender === 'female' ? '#ff8d98' : '#fff',
                }}>
                <Icon
                  name="female-outline"
                  size={28}
                  color={gender === 'female' ? '#fff' : '#ff8d98'}
                />
              </View>
            </Pressable>
            <Pressable onPress={() => setGender('male')}>
              <View
                // eslint-disable-next-line react-native/no-inline-styles
                style={{
                  ...styles.genderButton,
                  backgroundColor: gender === 'male' ? '#0084ff' : '#fff',
                }}>
                <Icon
                  name="male-outline"
                  size={28}
                  color={gender === 'male' ? '#fff' : '#0084ff'}
                />
              </View>
            </Pressable>
          </View>
          <RoundButton title="Filter" onPress={() => filterUsers()} />
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    alignItems: 'center',
  },
  fadingText: {
    fontSize: 28,
    textAlign: 'center',
    margin: 10,
    color: '#444444',
  },
  modal: {
    margin: 0,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'white',
    height: heightPercentageToDP('50%'),
    width: '95%',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    paddingHorizontal: 12,
  },
  modalText: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.textColor,
    textAlign: 'center',
  },
  desc: {
    color: '#7A7A7A',
    textAlign: 'center',
    fontSize: 14,
  },
  loader: {
    justifyContent: 'center',
    flex: 1,
  },
  locateButton: {
    position: 'absolute',
    alignSelf: 'flex-end',
    bottom: 70,
    right: 20,
    backgroundColor: 'white',
    padding: 6,
    borderRadius: 8,
  },
  selectedProfileContainer: {
    position: 'absolute',
    bottom: 100,
    backgroundColor: 'white',
    width: '95%',
    borderRadius: 12,
    flexDirection: 'row',
  },
  profilePic: {
    width: 80,
    height: 80,
    borderRadius: 12,
    bottom: heightPercentageToDP('4%'),
    left: 12,
  },
  markerPic: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  requestButton: {
    alignSelf: 'center',
    position: 'absolute',
    right: 10,
    top: 5,
  },
  margin: {
    marginHorizontal: 17,
  },
  animModalContainer: {
    backgroundColor: 'rgba(17, 17, 17, 0.8)',
    top: '50%',
    padding: 8,
    borderRadius: 8,
  },
  requestText: {
    color: '#fff',
  },
  filterDesc: {
    color: Colors.placeholderColor,
    textAlign: 'left',
    fontSize: 17,
  },
  sliderContainer: {
    alignItems: 'center',
  },
  genderButtonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginVertical: 12,
  },
  genderButton: {
    width: 150,
    height: 55,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 3,
    flexDirection: 'row',
  },
  slideMarker: {
    backgroundColor: 'white',
    padding: 10,
    flex: 1,
    width: widthPercentageToDP('12%'),
    height: heightPercentageToDP('6%'),
    borderRadius: 4,
    elevation: 3,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  markerText: {
    color: Colors.primary,
    fontSize: 15,
  },
  slideSelected: {
    backgroundColor: 'gold',
  },
  sliderTrack: {
    height: 4,
    borderRadius: 2,
  },
  sliderStyle: {
    height: 40,
  },
  reset: {
    position: 'absolute',
    right: 0,
  },
  modalHeader: {
    flexDirection: 'row',
  },
  closeAd: {
    position: 'relative',
    bottom: 62,
    borderRadius: 25 / 2,
    backgroundColor: '#fff',
    width: 25,
    height: 25,
  },
  adContainer: {
    marginBottom: 5,
    height: 60,
    position: 'absolute',
    bottom: 60,
  },
});

export default MainScreen;
