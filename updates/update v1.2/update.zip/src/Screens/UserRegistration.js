import {
  Image,
  Linking,
  PermissionsAndroid,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import {
  ProfilePic,
  dbTimeStamp,
  defaultAvtar,
  timeStamp,
  uploadPic,
  usersCol,
} from '../Utils/Utils';
import React, {useEffect, useRef, useState} from 'react';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import DateTimePicker from '@react-native-community/datetimepicker';
import Geolocation from 'react-native-geolocation-service';
import Icon from 'react-native-vector-icons/Ionicons';
import Input from '../Modules/Input';
import Modal from 'react-native-modal';
import OneSignal from 'react-native-onesignal';
import PressableText from '../Modules/PressableText';
import RoundButton from '../Modules/RoundButton';
import auth from '@react-native-firebase/auth';
import {displayName} from '../../app.json';
import {heightPercentageToDP} from '../Utils/DpToPixel';

const UserRegistration = (props) => {
  const [image, setImage] = useState('');
  const [pickerModal, setPickerModal] = useState(false);
  const [error, setError] = useState(null);
  const [gender, setGender] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [name, setName] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [dateOfBirth, setDateOfBirth] = useState(null);
  const [locationModal, setLocationModal] = useState(false);
  const [firebaseImage, setFirebaseImage] = useState(null);
  const [coords, setCoords] = useState(null);
  const [genderScreen, setGenderScreen] = useState(false);
  const [nameFocus, setNameFocus] = useState(false);
  const inputName = useRef(null);

  useEffect(() => {
    (async () => {
      accessLocation();
    })();
  }, []);

  const requestLocation = async () => {
    setLocationModal(false);
    try {
      console.log('Trying');
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: `${displayName} wants to access location`,
          message:
            `${displayName} use the location to find` + 'the best around you.',
          buttonNegative: 'Allow',
          buttonPositive: 'Deny',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        accessLocation();
      } else {
        if (granted === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN) {
          Linking.openSettings();
        }
      }
    } catch (err) {
      setError(
        'Error occured, while fetching location, contact to app administrators',
      );
    }
  };

  const accessLocation = async () => {
    Geolocation.getCurrentPosition(
      async (position) => {
        setCoords({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        });
      },
      (err) => {
        if (err.code === 1) {
          setLocationModal(true);
        } else {
          setError('Error while fetching location, ');
        }
      },
    );
  };

  const options = {
    mediaType: 'photo',
    maxWidth: 480,
    maxHeight: 480,
  };

  const imageHandler = async (response) => {
    if (!response.didCancel) {
      setImage(response.uri);
      setPickerModal(false);
    }
  };

  const detailHandler = async () => {
    setError(null);
    if (!name || !dateOfBirth) {
      setError('All fields are required');
    } else if (!dateOfBirth) {
      setError('Please provide date, so we can later use age to filter users');
    } else {
      if (name.length <= 3) {
        setError('Name must be greater than 3 characters');
      } else {
        if (!image) {
          setGenderScreen(true);
        } else {
          setIsLoading(true);
          try {
            const result = await uploadPic(
              ProfilePic(auth().currentUser.uid),
              image,
            );
            if (result) {
              setFirebaseImage(await result);
              setIsLoading(false);
              setGenderScreen(true);
            } else {
              setIsLoading(false);
              setError(
                'Unknown error occurred, please contact system administrator',
              );
            }
          } catch (err) {
            switch (err.code) {
              case 'storage/unauthorized':
                setError(
                  'You are not authorized to perform this action, please contact to system administrator',
                );
                break;
              case 'storage/unknown':
                setError(
                  'Unknown error occurred, please contact system administrator',
                );
                break;
              default:
                setError(
                  'Unexpected error occurred, please contact system administrator',
                );
                break;
            }
          }
        }
      }
    }
  };

  const createAccount = async () => {
    if (!gender) {
      setError('Please select gender to create account');
    } else {
      setIsLoading(true);
      try {
        const onesignalId = await OneSignal.getDeviceState();
        await usersCol.doc(auth().currentUser.uid).set({
          name: name,
          profileAvtar: firebaseImage
            ? firebaseImage
            : await defaultAvtar(gender),
          gender: gender,
          coords: coords,
          credit: 0,
          isVerified: false,
          createdAt: dbTimeStamp,
          friends: 0,
          onesignalId: onesignalId.userId,
          dateOfBirth: timeStamp.fromDate(dateOfBirth),
          bio: '',
          lastLogin: timeStamp.now(),
          membership: 'basic',
        });
        await auth().currentUser.updateProfile({
          displayName: name,
          photoURL: firebaseImage ? firebaseImage : await defaultAvtar(gender),
        });
        auth().onUserChanged((user) => user.reload());
        setIsLoading(false);
      } catch (err) {
        console.log('Errors => ', err);
      }
    }
  };

  const focusFunction = () => {
    setNameFocus(true);
    inputName.current.focus();
  };

  const dateChangeHandler = (event, date) => {
    if (event.type !== 'dismissed') {
      setDateOfBirth(date);
      setShowDatePicker(false);
    }
  };

  if (genderScreen) {
    return (
      <View style={styles.genderScreenContainer}>
        <Text
          style={
            styles.text
          }>{`Welcome ${name} please choose gender to create your account`}</Text>
        {!!gender && (
          <Image
            source={
              gender === 'male'
                ? require('../../assets/images/avtar_male.png')
                : require('../../assets/images/avtar_female.png')
            }
            style={styles.genderAvtar}
          />
        )}
        <Text style={styles.bold}>Select your Gender</Text>
        <View style={styles.genderMain}>
          <Pressable onPress={() => setGender('female')}>
            <View
              // eslint-disable-next-line react-native/no-inline-styles
              style={{
                ...styles.genderButton,
                backgroundColor: gender === 'female' ? '#ff8d98' : '#fff',
              }}>
              <Icon
                name="female-outline"
                size={42}
                color={gender === 'female' ? '#fff' : '#ff8d98'}
              />
            </View>
            <Text style={styles.text}>Female</Text>
          </Pressable>
          <Text style={styles.desc}>or</Text>
          <Pressable onPress={() => setGender('male')}>
            <View
              // eslint-disable-next-line react-native/no-inline-styles
              style={{
                ...styles.genderButton,
                backgroundColor: gender === 'male' ? '#0084ff' : '#fff',
              }}>
              <Icon
                name="male-outline"
                size={42}
                color={gender === 'male' ? '#fff' : '#0084ff'}
              />
            </View>
            <Text style={styles.text}>Male</Text>
          </Pressable>
        </View>
        {!!error && <CenterText text={error} />}
        <RoundButton
          title={genderScreen ? 'Create Acccount' : 'Next Step'}
          isLoading={isLoading}
          containerStyle={{marginTop: heightPercentageToDP('7%')}}
          onPress={!isLoading ? () => createAccount() : null}
        />
      </View>
    );
  }
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.bold}>Complete your profile</Text>
      <Text style={styles.desc}>
        Please enter your name and profile picture
      </Text>
      <View style={styles.space}>
        <Text style={styles.text}>Select Profile Picture</Text>
        <Pressable
          onPress={() => setPickerModal(true)}
          style={styles.imageContainer}>
          {!!image && (
            <Image
              source={{uri: image}}
              style={styles.profileAvtar}
              resizeMode="cover"
            />
          )}
          <Icon
            name="add-outline"
            size={32}
            color="#fff"
            style={styles.absolute}
          />
        </Pressable>
      </View>
      <Input
        onPress={() => focusFunction('name')}
        iconName={'person-outline'}
        focusEvent={nameFocus}
        ref={inputName}
        placeholder="Full Name"
        placeholderTextColor={
          nameFocus ? Colors.primary : Colors.placeholderColor
        }
        align="center"
        autoCapitalize="words"
        autoCompleteType="name"
        onFocus={() => focusFunction()}
        textContentType="name"
        maxLength={75}
        onChangeText={(val) => setName(val)}
      />
      <Input
        onPress={() => setShowDatePicker(true)}
        iconName={'calendar-outline'}
        placeholder="Date of birth"
        editable={false}
        dataDetectorTypes="calendarEvent"
        onPressIn={() => setShowDatePicker(true)}
        placeholderTextColor={
          nameFocus ? Colors.primary : Colors.placeholderColor
        }
        value={dateOfBirth?.toDateString()}
        align="center"
        maxLength={75}
      />
      {!!showDatePicker && (
        <DateTimePicker
          value={new Date()}
          mode={'date'}
          display="spinner"
          onChange={(e, date) => dateChangeHandler(e, date)}
        />
      )}
      <View style={styles.space}>
        <RoundButton
          title="Next"
          isLoading={isLoading}
          onPress={!isLoading ? () => detailHandler() : null}
        />
      </View>
      <Modal
        isVisible={pickerModal}
        style={styles.view}
        onBackButtonPress={() => setPickerModal(false)}
        onBackdropPress={() => setPickerModal(false)}>
        <View style={styles.modalContainer}>
          <Text style={styles.text}>Select</Text>
          <PressableText
            style={styles.modalButton}
            textStyle={styles.modalButtonText}
            icon={true}
            iconName="camera-outline"
            iconSize={32}
            iconColor={Colors.primary}
            text="Take Photo"
            onPress={() => launchCamera(options, imageHandler)}
          />
          <PressableText
            icon={true}
            style={styles.modalButton}
            textStyle={styles.modalButtonText}
            iconName="image-outline"
            iconSize={32}
            iconColor={Colors.primary}
            text="Choose from Gallery"
            onPress={() => launchImageLibrary(options, imageHandler)}
          />
        </View>
        {!!error && <CenterText text={error} />}
      </Modal>
      <Modal
        isVisible={locationModal}
        onBackdropPress={() => setLocationModal(false)}
        onBackButtonPress={() => setLocationModal(false)}
        style={styles.locationModal}>
        <View style={styles.locationModalContainer}>
          <Text style={styles.modalText}>Location required</Text>
          <View style={styles.line} />
          <Text style={styles.desc}>
            Please enable location services, so you can enjoy all the services
            of our
          </Text>
          <Text style={styles.locationButton} onPress={() => requestLocation()}>
            Allow
          </Text>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F4F4F4',
    top: 14,
  },
  bold: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    color: Colors.textColor,
  },
  desc: {
    color: '#7A7A7A',
    textAlign: 'center',
    fontSize: 18,
  },
  space: {
    marginTop: 13,
    marginBottom: 10,
  },
  text: {
    fontSize: 20,
    color: Colors.primary,
    textAlign: 'center',
    marginBottom: 8,
  },
  imageContainer: {
    height: 90,
    width: 90,
    backgroundColor: Colors.primary,
    borderRadius: 90 / 2,
    justifyContent: 'center',
    alignItems: 'center',
    opacity: 0.6,
    alignSelf: 'center',
  },
  profileAvtar: {
    width: 90,
    height: 90,
    borderRadius: 90 / 2,
  },
  absolute: {
    position: 'absolute',
  },
  view: {
    margin: 0,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: 'white',
    height: '15%',
    width: '95%',
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    justifyContent: 'center',
    alignItems: 'stretch',
  },
  modalButton: {
    alignItems: 'center',
    flexDirection: 'row',
    marginLeft: 20,
  },
  modalButtonText: {
    fontSize: 22,
    marginLeft: 12,
  },
  genderScreenContainer: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  genderAvtar: {
    width: 200,
    height: 200,
    borderRadius: 100,
    alignSelf: 'center',
    marginTop: 20,
    marginBottom: 15,
  },
  genderMain: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    marginTop: heightPercentageToDP('7%'),
  },
  genderButton: {
    width: 100,
    height: 100,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 3,
  },
  locationModalContainer: {
    backgroundColor: 'white',
    height: '25%',
    width: '70%',
    alignSelf: 'center',
    borderRadius: 12,
  },
  modalText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.textColor,
    textAlign: 'center',
  },
  locationButton: {
    backgroundColor: Colors.primary,
    color: 'white',
    fontSize: 18,
    bottom: 0,
    position: 'absolute',
    width: '100%',
    textAlign: 'center',
    padding: 10,
    borderRadius: 12,
  },
  line: {
    borderWidth: 1,
    borderColor: Colors.placeholderColor,
    marginBottom: 10,
    marginTop: 10,
  },
});

export default UserRegistration;
