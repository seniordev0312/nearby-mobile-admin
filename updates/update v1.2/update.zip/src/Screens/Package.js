import React, {useState} from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {db, dbTimeStamp, usersCol} from '../Utils/Utils';
import {heightPercentageToDP, widthPercentageToDP} from '../Utils/DpToPixel';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Icon from 'react-native-vector-icons/Ionicons';
import {PaymentRequest} from 'react-native-payments';
import RoundButton from '../Modules/RoundButton';
import {ScrollView} from 'react-native-gesture-handler';
import SiteConfig from '../Utils/Config';
import VerifiedBadge from '../Modules/VerifiedBadge';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';

const PackageCard = (props) => {
  return (
    <TouchableOpacity
      style={{...styles.card, backgroundColor: props.color}}
      onPress={props.onPress}>
      <Text style={styles.cardTitle}>{props.name}</Text>
      <Text
        style={
          styles.cardPrice
        }>{`${SiteConfig.CURRENCY_SYMBOL}${props.price}`}</Text>
      <View style={styles.cardLine} />
      <Text style={styles.cardTitle}>{props.discount}</Text>
    </TouchableOpacity>
  );
};

const PackageScreen = (props) => {
  const [error, setError] = useState(null);
  const payHandler = (name, price) => {
    const methodData = [
      {
        supportedMethods: ['apple-pay'],
        data: {
          merchantIdentifier: 'merchant.com.your-app.namespace',
          supportedNetworks: ['visa', 'mastercard', 'amex'],
          countryCode: 'US',
          currencyCode: 'USD',
          paymentMethodTokenizationParameters: {
            parameters: {
              gateway: 'stripe',
              'stripe:publishableKey': SiteConfig.STRIPE_KEY,
            },
          },
        },
      },
      {
        supportedMethods: ['android-pay'],
        data: {
          supportedNetworks: ['visa', 'mastercard', 'amex'],
          currencyCode: 'USD',
          environment: 'TEST', // defaults to production
          paymentMethodTokenizationParameters: {
            tokenizationType: 'GATEWAY_TOKEN',
            parameters: {
              gateway: 'stripe',
              publicKey: SiteConfig.STRIPE_KEY,
            },
          },
        },
      },
    ];
    const displayItems = [
      {
        label: name,
        amount: {
          currency: SiteConfig.CURRENCY_CODE,
          value: price,
        },
      },
    ];
    const total = {
      label: 'Total',
      amount: {
        currency: SiteConfig.CURRENCY_CODE,
        value: price,
      },
    };
    const details = {
      displayItems,
      total,
    };

    const paymentRequest = new PaymentRequest(methodData, details);
    paymentRequest
      .show()
      .then(async (paymentResponse) => {
        const {
          transactionIdentifier,
          paymentData,
          paymentToken,
          getPaymentToken,
        } = paymentResponse.details;
        let androidToken = await getPaymentToken();
        if (paymentToken || androidToken) {
          await paymentResponse.complete('success');
          await db
            .collection('payments')
            .doc(auth().currentUser.uid)
            .set({
              token: paymentToken,
              username: auth().currentUser.displayName,
              createdOn: dbTimeStamp,
              purchased: name,
              paid: price,
              paymentData: paymentData,
              identifier: transactionIdentifier,
              androidPay: androidToken,
            })
            .then(() => {
              usersCol.doc(auth().currentUser.uid).update({
                isVerified: true,
                credit: firestore.FieldValue.increment(1000),
                membership: name,
                isFeatured: true,
              });
            })
            .then(() => {
              db.collection('featuredUsers').doc(auth().currentUser.uid).set(
                {
                  username: auth().currentUser.displayName,
                  profileAvtar: auth().currentUser.photoURL,
                  membership: name,
                  createdOn: dbTimeStamp,
                },
                {
                  merge: true,
                },
              );
            })
            .then(() => {
              props.navigation.navigate('Profile');
            });
        } else {
          setError('Error occured while processing payment');
        }
      })
      .catch((err) => {
        if (err === 409) {
          return false;
        }
      });
  };

  return (
    <View style={styles.body}>
      <ScrollView style={styles.container}>
        <Text style={styles.heading}>Upgrade to Premium</Text>
        <Text style={styles.desc}>
          Activating Premium will help you, get verified faster and send gifts
          to your friends
        </Text>
        <View style={styles.inLine}>
          <VerifiedBadge size={28} style={styles.badge} />
          <Text style={styles.title}>Get Verified Badge</Text>
        </View>
        <View style={styles.inLine}>
          <Icon name="cash" size={32} color="#00897b" />
          <Text style={styles.title}>Get 1000 Credits for free</Text>
        </View>
        <View style={styles.inLine}>
          <Icon name="flash" color="#8e24aa" size={32} />
          <Text style={styles.title}>Get featured</Text>
        </View>
        <View style={styles.inLine}>
          <Icon name="headset" color="#1e88e5" size={32} />
          <Text style={styles.title}>Get 24/7 support </Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <PackageCard
            name={SiteConfig.BRONZE_PACKAGE_NAME}
            price={SiteConfig.BRONZE_PACKAGE}
            discount="Normal"
            color={Colors.bronzePackage}
            onPress={() =>
              payHandler(
                SiteConfig.BRONZE_PACKAGE_NAME,
                SiteConfig.BRONZE_PACKAGE,
              )
            }
          />
          <PackageCard
            name={SiteConfig.SILVER_PACKAGE_NAME}
            price={SiteConfig.SILVER_PACKAGE}
            discount="Save 51%"
            color={Colors.silverPackage}
            onPress={() =>
              payHandler(
                SiteConfig.SILVER_PACKAGE_NAME,
                SiteConfig.SILVER_PACKAGE,
              )
            }
          />
          <PackageCard
            name={SiteConfig.GOLD_PACKAGE_NAME}
            price={SiteConfig.GOLD_PACKAGE}
            discount="Save 90%"
            color={Colors.goldPackage}
            onPress={() =>
              payHandler(SiteConfig.GOLD_PACKAGE_NAME, SiteConfig.GOLD_PACKAGE)
            }
          />
        </ScrollView>
        <RoundButton
          title="Get Monthly"
          containerStyle={styles.buyButton}
          onPress={() =>
            payHandler(
              SiteConfig.BRONZE_PACKAGE_NAME,
              SiteConfig.BRONZE_PACKAGE,
            )
          }
        />
      </ScrollView>
      {!!error && <CenterText text={error} />}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: heightPercentageToDP('8%'),
    marginHorizontal: widthPercentageToDP('6%'),
  },
  body: {
    flex: 1,
    backgroundColor: '#fff',
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  desc: {
    color: Colors.placeholderColor,
    fontSize: 18,
  },
  inLine: {
    flexDirection: 'row',
    marginVertical: 10,
    alignItems: 'center',
  },
  badge: {
    position: 'relative',
    width: 32,
    height: 32,
    borderRadius: 32 / 2,
  },
  title: {
    marginHorizontal: 15,
    fontSize: 18,
    color: Colors.primary,
  },
  card: {
    width: 150,
    height: 150,
    borderRadius: 13,
    alignItems: 'center',
    elevation: 3,
    paddingVertical: 8,
    justifyContent: 'space-evenly',
    marginHorizontal: 10,
  },
  cardTitle: {
    color: '#fff',
    fontSize: 22,
  },
  cardPrice: {
    fontSize: 32,
    fontWeight: '700',
    color: '#fff',
  },
  cardLine: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#fff',
    width: '90%',
  },
  buyButton: {
    marginVertical: heightPercentageToDP('10%'),
  },
});

export default PackageScreen;
