import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React, {useRef, useState} from 'react';

import CenterText from '../Modules/CenterText';
import Colors from '../Utils/Colors';
import Input from '../Modules/Input';
import Modal from 'react-native-modal';
import PressableText from '../Modules/PressableText';
import RoundButton from '../Modules/RoundButton';
import auth from '@react-native-firebase/auth';
import {widthPercentageToDP} from '../Utils/DpToPixel';

let confirmation;

const SigninScreen = (props) => {
  const [inputFocus, setInputFocus] = useState({
    email: false,
    password: false,
  });
  const [phoneInputFous, setPhoneInputFous] = useState(false);
  const [forgoInput, setForgoInput] = useState(false);
  const [confirmFocus, setConfirmFocus] = useState(false);
  const [confirmCode, setConfirmCode] = useState(false);
  const [isPasswordHidden, setIsPasswordHidden] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneModal, setPhoneModal] = useState(false);
  const [error, setError] = useState(null);
  const [confirmationScreen, setConfirmationScreen] = useState(false);
  const [forgotModal, setForgotModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const inputEmail = useRef(null);
  const inputPass = useRef(null);
  const inputPhone = useRef(null);
  const inputCode = useRef(null);
  const inputForgo = useRef(null);

  const focusFunction = (input) => {
    if (input === 'email') {
      setInputFocus({password: false, email: true});
      inputEmail.current.focus();
    } else {
      setInputFocus({email: false, password: true});
      inputPass.current.focus();
    }
  };

  const forgoFocus = (input) => {
    setForgoInput(true);
    inputForgo.current.focus();
  };

  const phoneFocus = (input) => {
    if (input === 'phone') {
      setPhoneInputFous(true);
      inputPhone.current.focus();
    } else {
      setConfirmFocus(true);
      inputCode.current.focus();
    }
  };

  const loginFunction = async () => {
    setError(null);
    if (!email || !password) {
      setError('Email & password fields are required');
    } else if (email.length <= 3) {
      setError('Email must not be less than 3 characters');
    } else if (password.length <= 5) {
      setError('Password must be at least 5 characters');
    } else {
      setIsLoading(true);
      try {
        await auth().signInWithEmailAndPassword(email, password);
        setIsLoading(false);
      } catch (err) {
        switch (err.code) {
          case 'auth/invalid-email':
            setError('Email address is not valid');
            break;
          case 'auth/user-disabled':
            setError(
              'Your account has been disabled, please contact to administrator',
            );
            break;
          case 'auth/user-not-found':
            setError('User not found, please signup');
            break;
          case 'auth/wrong-password':
            setError('Password is invalid');
            break;
          default:
            break;
        }
        setIsLoading(false);
      }
    }
  };

  const forgotPass = async () => {
    setError(null);
    if (!email) {
      setError('Please provide email');
    } else {
      try {
        setIsLoading(true);
        await auth().sendPasswordResetEmail(email);
        setIsLoading(false);
      } catch (err) {
        switch (err.code) {
          case 'auth/user-not-found':
            setError('Account not found, please signup');
            break;
          default:
            setError(
              'Unexpected error occured, please contact to system administrator',
            );
            break;
        }
      }
    }
  };

  //Phone authentication handler
  const phoneAuthHandler = async () => {
    setIsLoading(true);
    try {
      confirmation = await auth().signInWithPhoneNumber(phoneNumber);
      setIsLoading(false);
      setConfirmationScreen(true);
    } catch (err) {
      switch (err.code) {
        case 'auth/invalid-phone-number':
          setError(
            'Invalid number, please check your number in international format i.e [+][Country Code][Number]',
          );
          break;
        case 'auth/quota-exceeded':
          setError('Your request is blocked, due to too many attempt');
          break;
        case 'auth/user-disabled':
          setError(
            'Unfortunately your account has been disabled, please contact to administrator!',
          );
          break;
        case 'auth/too-many-requests':
          setError(
            'We have blocked requests from your device, due to too many unsual requests. Please try later',
          );
          break;
        default:
          console.log('Error from main => ', err);
          setError('Something went wrong, please try again later');
          break;
      }
      setIsLoading(false);
    }
  };

  const verificationHandler = async () => {
    if (confirmationScreen) {
      setIsLoading(true);
      setConfirmationScreen(false);
      try {
        await confirmation.confirm(confirmCode);
        setIsLoading(false);
      } catch (err) {
        setIsLoading(false);
        switch (err.code) {
          case 'auth/invalid-verification-code':
            setError('Invalid verification code, Please try again');
            break;
          case 'auth/missing-verification-code':
            setError('Please enter the verification code');
            break;
          default:
            console.log('Error => ', err);
            setError('Something is missing, please check that');
            break;
        }
      }
    }
  };

  const verificationScreen = () => {
    return (
      <View style={styles.modalElemContainer}>
        <Text style={styles.modalText}>Verification Code</Text>
        <Text style={styles.modalDescText}>
          Enter the six digit long code, sent on your mobile number
        </Text>
        <Input
          onPress={() => phoneFocus()}
          focusEvent={confirmFocus}
          ref={inputCode}
          placeholderTextColor={
            inputCode ? Colors.primary : Colors.placeholderColor
          }
          onFocus={() => phoneFocus()}
          keyboardType={'number-pad'}
          inputStyle={styles.verifiationStyle}
          maxLength={6}
          onChangeText={(val) => setConfirmCode(val)}
        />
        {!!error && <CenterText text={error} />}
        <RoundButton
          title="Signin"
          containerStyle={styles.forgetButton}
          isLoading={isLoading}
          onPress={() => verificationHandler()}
        />
      </View>
    );
  };

  return (
    <ScrollView>
      <Pressable
        onPress={() => {
          setInputFocus(
            Object.assign(
              ...Object.keys(inputFocus).map((k) => ({[k]: false})),
            ),
          );
          inputEmail.current.blur();
          inputPass.current.blur();
        }}
        style={styles.container}>
        <Image
          source={require('../../assets/images/Logo.png')}
          style={styles.logo}
        />
        <Text style={styles.bold}>Welcome back!</Text>
        <Text style={styles.desc}>Log in to your existant account</Text>

        <Input
          onPress={() => focusFunction('email')}
          iconName={'mail-outline'}
          focusEvent={inputFocus.email}
          ref={inputEmail}
          placeholder={'Email'}
          placeholderTextColor={
            inputFocus.email ? Colors.primary : Colors.placeholderColor
          }
          align="center"
          onFocus={() => focusFunction('email')}
          keyboardType={'email-address'}
          returnKeyType={'next'}
          textContentType="emailAddress"
          maxLength={254}
          onSubmitEditing={() => inputPass.current.focus()}
          onChangeText={(val) => setEmail(val)}
        />
        <Input
          onPress={() => focusFunction()}
          iconName={'lock-open-outline'}
          focusEvent={inputFocus.password}
          ref={inputPass}
          maxLength={128}
          align="center"
          placeholder={'Password'}
          placeholderTextColor={
            inputFocus.password ? Colors.primary : Colors.placeholderColor
          }
          onFocus={() => setInputFocus({email: false, password: true})}
          secureTextEntry={isPasswordHidden}
          isEye={true}
          eyePress={() => setIsPasswordHidden(!isPasswordHidden)}
          passIcon={!isPasswordHidden ? 'eye-outline' : 'eye-off-outline'}
          onChangeText={(val) => setPassword(val)}
        />
        <PressableText
          text="Forgot password?"
          style={styles.forgot}
          textStyle={styles.forgPassword}
          onPress={() => setForgotModal(true)}
        />
        {!!error && <CenterText text={error} />}
        <RoundButton
          title="LOG IN"
          isLoading={isLoading}
          onPress={() => !isLoading && loginFunction()}
        />
        <Text style={styles.orText}>or connect using</Text>
        <RoundButton
          title="Phone Number"
          icon={true}
          iconName={'phone-portrait-outline'}
          iconSize={22}
          containerStyle={styles.phoneButton}
          iconColor={'#fff'}
          onPress={() => setPhoneModal(true)}
        />
        <Modal
          isVisible={forgotModal}
          style={styles.view}
          onBackButtonPress={() => !isLoading && setForgotModal(false)}
          onBackdropPress={() => !isLoading && setForgotModal(false)}>
          <Pressable
            onPress={() => {
              setForgoInput(false);
              inputForgo.current.blur();
            }}
            style={styles.modalContainer}>
            <View style={styles.modalElemContainer}>
              <Text style={styles.modalText}>Forgot password</Text>
              <Text style={styles.modalDescText}>
                Enter your email address, we'll send you the password reset link
                to reset your password
              </Text>
              <Input
                onPress={() => forgoFocus()}
                iconName={'mail-outline'}
                focusEvent={forgoInput}
                ref={inputForgo}
                placeholder={'Email'}
                placeholderTextColor={
                  forgoInput ? Colors.primary : Colors.placeholderColor
                }
                onFocus={() => forgoFocus()}
                keyboardType={'email-address'}
                textContentType="emailAddress"
                maxLength={254}
                onChangeText={(val) => setEmail(val)}
              />
              {!!error && <CenterText text={error} />}
              <RoundButton
                title="Send link"
                containerStyle={styles.forgetButton}
                isLoading={isLoading}
                onPress={() => !isLoading && forgotPass()}
              />
            </View>
          </Pressable>
        </Modal>
        <Modal
          isVisible={phoneModal}
          style={styles.view}
          onBackButtonPress={() => !isLoading && setPhoneModal(false)}
          onBackdropPress={() => !isLoading && setPhoneModal(false)}>
          <Pressable
            onPress={() => {
              setPhoneInputFous(false);
              setConfirmFocus(false);
              !confirmationScreen
                ? inputPhone.current.blur()
                : inputCode.current.blur();
            }}
            style={styles.modalContainer}>
            {confirmationScreen ? (
              verificationScreen
            ) : (
              <View>
                <View style={styles.modalLine} />
                <View style={styles.modalElemContainer}>
                  <Text style={styles.modalText}>
                    Signin with your mobile number
                  </Text>
                  <Text style={styles.modalDescText}>
                    Enter your mobile number
                  </Text>
                  <Input
                    onPress={() => phoneFocus('phone')}
                    iconName={'call-outline'}
                    focusEvent={phoneInputFous}
                    ref={inputPhone}
                    placeholder={'e.g +923212325161'}
                    placeholderTextColor={
                      phoneInputFous ? Colors.primary : Colors.placeholderColor
                    }
                    onFocus={() => phoneFocus('phone')}
                    keyboardType={'phone-pad'}
                    textContentType="telephoneNumber"
                    maxLength={15}
                    onChangeText={(val) => setPhoneNumber(val)}
                  />
                  {!!error && <CenterText text={error} />}
                  <RoundButton
                    title="Send Code"
                    containerStyle={styles.forgetButton}
                    isLoading={isLoading}
                    onPress={() => phoneAuthHandler()}
                  />
                </View>
              </View>
            )}
          </Pressable>
        </Modal>
        <View style={styles.signUpContainer}>
          <Text style={styles.signupText}>Don't have an account? </Text>
          <PressableText
            textStyle={styles.signup}
            text="Sign up"
            onPress={() => !isLoading && props.navigation.navigate('Signup')}
          />
        </View>
      </Pressable>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F4F4F4',
  },
  logo: {
    width: 100,
    height: 100,
  },
  bold: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    color: Colors.textColor,
  },
  desc: {
    color: '#7A7A7A',
    textAlign: 'center',
    fontSize: 18,
  },
  forgot: {
    alignSelf: 'flex-end',
  },
  forgPassword: {
    color: Colors.primary,
    fontSize: 16,
    fontWeight: '700',
    marginRight: 10,
    marginBottom: 7,
  },
  signUpContainer: {
    flexDirection: 'row',
    marginTop: '15%',
    alignSelf: 'center',
  },
  orText: {
    color: '#7A7A7A',
    textAlign: 'center',
    fontSize: 18,
    marginTop: '13%',
  },
  signupText: {
    fontSize: 18,
  },
  signup: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  errorContainer: {
    alignSelf: 'center',
    margin: 8,
  },
  errorText: {
    color: '#ff0033',
    fontSize: 18,
  },
  phoneButton: {
    backgroundColor: Colors.secondary,
    borderRadius: 12,
    width: widthPercentageToDP('48%'),
    height: 50,
    marginTop: 17,
  },
  modalContainer: {
    backgroundColor: '#F2F2F2',
    height: '50%',
    width: '100%',
    borderTopLeftRadius: 14,
    borderTopRightRadius: 14,
  },
  view: {
    margin: 0,
    justifyContent: 'flex-end',
  },
  modalText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.textColor,
  },
  modalElemContainer: {
    left: '3%',
    top: '8%',
  },
  modalDescText: {
    color: '#7A7A7A',
    marginTop: 8,
    fontSize: 16,
  },
  verificationStyle: {
    width: '100%',
    letterSpacing: 30,
    textAlign: 'center',
  },
  modalLine: {
    width: '10%',
    borderBottomWidth: 3,
    borderBottomColor: '#8e8e8e',
    alignSelf: 'center',
    marginTop: 10,
  },
  forgetButton: {
    right: 8,
  },
});

export default SigninScreen;
