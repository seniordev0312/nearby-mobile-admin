const SiteConfig = {
  MIN_AGE: 0,
  MAX_AGE: 60,
  MIN_RANGE: 0, //IN KM
  MAX_RANGE: 200, //In KM
  CURRENCY_SYMBOL: '$', //Should be a string;
  CURRENCY_CODE: 'USD',
  BRONZE_PACKAGE: 70, //Referred to as Monthly package;
  SILVER_PACKAGE: 130, //Referred to as for 6 months;
  GOLD_PACKAGE: 280,
  BRONZE_PACKAGE_NAME: 'Monthly', //Should be a string;
  SILVER_PACKAGE_NAME: '6 Months',
  GOLD_PACKAGE_NAME: 'Yearly',
  STRIPE_KEY: 'YOUR_STRIPE_KEY',
  THOUSAND_COINS_EQUALS: 20, // equals your currencey rate.
  MIN_WITHDRAW: 50, //Must be number.
  PER_COIN_EQUAL_TO: 10, //Equal to the currency rate.
  ONESIGNAL_APP_ID: 'f6dad05e-4f3d-42de-b498-1a6966cf6e21',
  BANNER_ADD_ID: {
    ANDROID: 'ca-app-pub-9245689738175771/9444164380',
    IOS: 'ca-app-pub-9245689738175771/1169895028',
  },
  FULLSCREEN_AD: {
    ANDROID: 'ca-app-pub-9245689738175771/8655495197',
    IOS: 'ca-app-pub-9245689738175771/4917568344',
  },
};

export default SiteConfig;
