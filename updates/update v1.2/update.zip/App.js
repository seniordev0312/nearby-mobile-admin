import {
  Image,
  Linking,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
/**
 * @format
 * @flow strict-local
 */
import React, {useEffect, useState} from 'react';

import AboutUs from './src/Screens/AboutUs';
import ChatScreen from './src/Screens/ChatScreen';
import Colors from './src/Utils/Colors';
import Config from './src/Utils/Config';
import Discover from './src/Screens/Discover';
import DrawerSideBar from './src/Screens/Drawer';
import Icon from 'react-native-vector-icons/Ionicons';
import MainScreen from './src/Screens/Main';
import MessagesScreen from './src/Screens/Messages';
import {NavigationContainer} from '@react-navigation/native';
import NotificationsScreen from './src/Screens/NotificationsScreen';
import OneSignal from 'react-native-onesignal';
import OurTerms from './src/Screens/Terms';
import PackageScreen from './src/Screens/Package';
import PrivacyPolicy from './src/Screens/PrivacyPolicy';
import ProfileScreen from './src/Screens/Profile';
import SettingsScreen from './src/Screens/Settings';
import SigninScreen from './src/Screens/SigninScreen';
import SignupScreen from './src/Screens/Signup';
import SplashScreen from './src/Screens/Splashscreen';
import SupportScreen from './src/Screens/Support';
import UserProfile from './src/Screens/UserScreen';
import UserRegisterScreen from './src/Screens/UserRegistration';
import VerificationScreen from './src/Screens/VerificationScreen';
import WithdrawScreen from './src/Screens/Withdraw';
import auth from '@react-native-firebase/auth';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {createStackNavigator} from '@react-navigation/stack';
import {isUserExists} from './src/Utils/Utils';
import {navigationRef} from './src/Utils/RootNavigation';

const BottomTab = createBottomTabNavigator();

const Stack = createStackNavigator();

const Drawer = createDrawerNavigator();

function HomeComp() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Home"
        component={MainScreen}
        initialParams={{isFocused: false}}
        options={({navigation, route}) => ({
          headerTransparent: true,
          headerTitle: () => <View />,
          headerLeft: () => (
            <Pressable
              style={styles.iconMargin}
              onPress={() => navigation.openDrawer()}>
              <Icon name="menu-outline" size={28} color={Colors.primary} />
            </Pressable>
          ),
          headerRight: () => (
            <Pressable
              style={styles.iconMargin}
              onPress={() => navigation.setParams({isFocused: true})}>
              <Icon name="funnel" size={28} color={Colors.primary} />
            </Pressable>
          ),
        })}
      />
    </Stack.Navigator>
  );
}

function DrawerTab() {
  return (
    <Drawer.Navigator drawerContent={(props) => <DrawerSideBar {...props} />}>
      <Drawer.Screen name="Home" component={HomeComp} />
    </Drawer.Navigator>
  );
}

function MessageComp() {
  return (
    <Stack.Navigator initialRouteName="MessagesScreen">
      <Stack.Screen
        name="MessagesScreen"
        options={() => ({
          headerShown: false,
        })}
        component={MessagesScreen}
      />
    </Stack.Navigator>
  );
}

function ProfileComp() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        initialParams={{credit: 0}}
        name="Profile"
        component={ProfileScreen}
        options={({navigation, route}) => ({
          headerTransparent: true,
          headerTitle: 'Profile',
          headerTitleAlign: 'center',
          headerTitleStyle: {
            fontFamily: 'GothamMedium',
          },
          headerLeft: () => (
            <View style={styles.row}>
              <Text style={styles.title}>Credit: </Text>
              {!!route.params.credit.toString() && (
                <Text style={styles.credit}>
                  {route.params.credit.toString()}
                </Text>
              )}
            </View>
          ),
          headerRight: () => (
            <Pressable
              style={styles.iconMargin}
              onPress={() => navigation.setParams({isFocused: true})}>
              <Icon name="log-out-outline" size={28} color={Colors.primary} />
            </Pressable>
          ),
        })}
      />
      <Stack.Screen
        name="VerificationScreen"
        component={VerificationScreen}
        options={({navigation}) => ({
          headerTitle: 'Request Verification',
        })}
      />
      <Stack.Screen
        name="Settings"
        component={SettingsScreen}
        options={({navigation}) => ({
          headerTitle: () => <Text style={styles.heading}>Account</Text>,
          headerTransparent: true,
          headerLeft: () => (
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}>
              <Icon
                name="arrow-back-outline"
                size={28}
                color={Colors.primary}
              />
            </TouchableOpacity>
          ),
        })}
      />
      <Stack.Screen
        name="PackageScreen"
        component={PackageScreen}
        options={({navigation}) => ({
          headerTransparent: true,
          headerTitle: () => <View />,
        })}
      />
      <Stack.Screen
        name="UserScreen"
        component={UserProfile}
        options={({navigation, route}) => ({
          headerTransparent: true,
          headerTitle: () => (
            <Text style={styles.heading}>{route.params.name}</Text>
          ),
        })}
      />
      <Stack.Screen name="AboutUs" component={AboutUs} />
      <Stack.Screen name="Terms" component={OurTerms} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} />
      <Stack.Screen
        name="Support"
        component={SupportScreen}
        options={({navigation, route}) => ({
          headerTransparent: true,
        })}
      />
      <Stack.Screen
        name="Withdraw"
        component={WithdrawScreen}
        options={({navigation, route}) => ({
          headerTransparent: true,
          headerLeft: () => (
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}>
              <Icon
                name="arrow-back-outline"
                size={28}
                color={Colors.primary}
              />
            </TouchableOpacity>
          ),
        })}
      />
    </Stack.Navigator>
  );
}

function mainComp() {
  return (
    <BottomTab.Navigator
      tabBarOptions={{
        showLabel: false,
        showIcon: true,
        style: {
          position: 'absolute',
          height: 50,
          elevation: 0,
          shadowOpacity: 0,
          borderTopWidth: 0.5,
          bottom: 0,
        },
      }}
      initialRouteName="Home"
      backBehavior="history">
      <BottomTab.Screen
        name="Messages"
        component={MessageComp}
        listeners={({navigation}) => ({
          tabPress: (e) => {
            navigation.navigate('Profile', {screen: 'MessagesScreen'});
          },
        })}
        options={{
          tabBarIcon: (tabInfo) => (
            <Icon
              name={tabInfo.focused ? 'paper-plane' : 'paper-plane-outline'}
              size={28}
              color={
                tabInfo.focused ? Colors.messageTabFocused : Colors.tabUnFocused
              }
            />
          ),
        }}
      />
      <BottomTab.Screen
        name="Discover"
        component={Discover}
        options={{
          tabBarIcon: (tabInfo) => (
            <Icon
              name={tabInfo.focused ? 'earth' : 'earth-outline'}
              size={28}
              color={
                tabInfo.focused
                  ? Colors.discoverTabFocused
                  : Colors.tabUnFocused
              }
            />
          ),
        }}
      />
      <BottomTab.Screen
        name="Home"
        component={DrawerTab}
        options={{
          tabBarIcon: (tabInfo) => (
            <Icon
              name={tabInfo.focused ? 'home' : 'home-outline'}
              size={24}
              color={
                tabInfo.focused ? Colors.homeTabFocused : Colors.tabUnFocused
              }
            />
          ),
        }}
      />
      <BottomTab.Screen
        name="Notifications"
        component={NotificationsScreen}
        options={{
          tabBarIcon: (tabInfo) => (
            <Icon
              name={tabInfo.focused ? 'notifications' : 'notifications-outline'}
              size={24}
              color={
                tabInfo.focused
                  ? Colors.notificationTabFocused
                  : Colors.tabUnFocused
              }
            />
          ),
        }}
      />
      <BottomTab.Screen
        name="Profile"
        component={ProfileComp}
        listeners={({navigation}) => ({
          tabPress: (e) => {
            navigation.navigate('Profile', {screen: 'Profile'});
          },
        })}
        initialParams={{
          title: 'Profile',
        }}
        options={{
          tabBarIcon: (tabInfo) => (
            <Icon
              name={tabInfo.focused ? 'person' : 'person-outline'}
              size={24}
              color={
                tabInfo.focused ? Colors.profileTabFocused : Colors.tabUnFocused
              }
            />
          ),
        }}
      />
    </BottomTab.Navigator>
  );
}

const App = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isUser, setIsUser] = useState(false);
  const [isFirstScreen, setIsFirstScreen] = useState(false);

  const linking = {
    prefixes: ['nearby://'],
    config: {
      screens: {
        ChatScreen: {
          path: 'chat/:userid/:dp/:username/:onesignalId',
          parse: {
            username: (username) => decodeURIComponent(username),
            dp: (dp) => decodeURIComponent(dp),
          },
        },
        MainComp: {
          screens: {
            Notifications: {
              path: 'notification/',
            },
          },
        },
      },
    },
  };

  React.useEffect(() => {
    const NotificationHandling = async () => {
      OneSignal.setAppId(Config.ONESIGNAL_APP_ID);
      OneSignal.setLogLevel(6, 0);
      OneSignal.setRequiresUserPrivacyConsent(false);

      //OneSignal Handlers
      OneSignal.setNotificationWillShowInForegroundHandler(
        async (notifReceivedEvent) => {
          let notif = notifReceivedEvent.getNotification();
          console.log('Notif => ', notif);
          notifReceivedEvent.complete(notif);
        },
      );

      OneSignal.setNotificationOpenedHandler(async (notification) => {
        if (notification.notification.launchURL) {
          if (isUser) {
            Linking.openURL(notification.notification.launchURL);
          }
        }
      });
    };
    return () => NotificationHandling();
  }, [isUser]);

  useEffect(() => {
    const unsubscribe = auth().onUserChanged(async (user) => {
      //If user updated his profile, then navigate to Home Screen else Show Registering Screen,
      if (!user) {
        setIsUser(null);
        setIsLoading(false);
        return false;
      }
      if (user.uid) {
        if (
          (await isUserExists(user.uid)) &&
          user.displayName !== null &&
          user.photoURL !== null
        ) {
          setIsUser(user);
          setIsFirstScreen(false);
          setIsLoading(false);
        } else {
          setIsUser(null);
          setIsFirstScreen(true);
          setIsLoading(false);
        }
      }
    });
    return () => {
      unsubscribe();
    };
  }, []);

  if (isLoading) {
    return <SplashScreen />;
  }

  if (isFirstScreen) {
    return <UserRegisterScreen />;
  }

  return (
    <NavigationContainer ref={navigationRef} linking={linking}>
      {!isUser ? (
        <>
          <Stack.Navigator initialRouteName={'SignIn'}>
            <Stack.Screen
              headerMode="none"
              name="SignIn"
              options={{
                animationTypeForReplace: !isUser ? 'pop' : 'push',
                headerShown: false,
              }}
              component={SigninScreen}
            />
            <Stack.Screen
              name="Signup"
              options={{
                headerShown: Platform.OS === 'ios' ? true : false,
                headerTransparent: true,
                headerTitle: '',
                headerTitleStyle: {
                  textAlign: 'center',
                  color: Colors.primary,
                },
                headerLeft: () => (
                  <Pressable style={styles.margin}>
                    <Icon
                      name="arrow-back-outline"
                      size={28}
                      color={Colors.primary}
                    />
                  </Pressable>
                ),
              }}
              component={SignupScreen}
            />
          </Stack.Navigator>
        </>
      ) : (
        <>
          <Stack.Navigator initialRouteName={'MainComp'}>
            <Stack.Screen
              headerMode="none"
              options={{
                headerShown: false,
              }}
              name="MainComp"
              component={mainComp}
            />
            <Stack.Screen
              name="ChatScreen"
              component={ChatScreen}
              options={({navigation, route}) => ({
                headerStyle: {
                  elevation: 0,
                  shadowOpacity: 0,
                  borderBottomWidth: 0.5,
                },
                headerTitle: () => (
                  <Text style={styles.title}>{route.params.username}</Text>
                ),
                headerLeft: () => (
                  <TouchableOpacity
                    style={styles.headerLeft}
                    onPress={() => {
                      navigation.goBack();
                    }}>
                    <Icon name="ios-arrow-back" size={18} color="#242424" />
                    <Image
                      source={{uri: route.params.dp}}
                      style={styles.image}
                      resizeMode="cover"
                    />
                  </TouchableOpacity>
                ),
              })}
            />
          </Stack.Navigator>
        </>
      )}
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  iconMargin: {
    marginHorizontal: 10,
  },
  backButton: {
    width: '80%',
    height: '50%',
    borderRadius: 5,
    backgroundColor: '#fff',
    marginHorizontal: 10,
    elevation: 2,
    alignSelf: 'baseline',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  title: {
    fontSize: 14,
    fontFamily: 'GothamMedium',
  },
  heading: {
    fontFamily: 'GothamBold',
    fontSize: 20,
  },
  credit: {
    fontSize: 13,
    fontFamily: 'GothamMedium',
  },
  row: {
    flexDirection: 'row',
  },
  margin: {marginLeft: 6},
  headerLeft: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  image: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
});

export default App;
